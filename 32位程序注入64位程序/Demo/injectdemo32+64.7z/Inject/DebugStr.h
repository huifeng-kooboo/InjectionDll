#pragma once
#include <Windows.h>

void FmtDebugOut(LPCWSTR szFmt, ...);


void FmtDebugOutA(LPCSTR szFmt, ...);