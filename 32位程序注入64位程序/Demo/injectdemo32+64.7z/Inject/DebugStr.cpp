#include "stdafx.h"
#include "DebugStr.h"

void FmtDebugOut(LPCWSTR szFmt, ...)
{
	va_list arg;
	va_start(arg, szFmt);
	wchar_t szBuf[MAX_PATH*4] = {0};
	_vsnwprintf_s(szBuf, MAX_PATH*4, sizeof(szBuf) / sizeof(wchar_t) - 1, szFmt, arg);
	va_end(arg);
	::OutputDebugString(szBuf);
}

void FmtDebugOutA(LPCSTR szFmt, ...)
{
	va_list arg;
	va_start(arg, szFmt);
	char szBuf[MAX_PATH*4] = {0};
	_vsnprintf_s(szBuf, MAX_PATH*4, sizeof(szBuf) / sizeof(wchar_t) - 1, szFmt, arg);
	va_end(arg);
	OutputDebugStringA(szBuf);
}
