#pragma once
#include "Helper.h"

InjectResult Inject64Silent(DWORD dwPid, const wchar_t* szDllName, const char* szFunName, const char* szParam);

InjectResult Inject64WithErrorPrompt(DWORD dwPid, const wchar_t* szDllName, const char* szFunName, const char* szParam);