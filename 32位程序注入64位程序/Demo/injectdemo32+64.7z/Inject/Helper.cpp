#include "stdafx.h"
#include <iostream>
#include "Helper.h"

struct InjectErrorDesc
{
	InjectResult code;
	wchar_t* des;

	InjectErrorDesc(InjectResult _code, wchar_t* _des)
	{
		code = _code;
		des = _des;
	}
};

#define Declare_Error(Err)	InjectErrorDesc(Err, L###Err),

InjectErrorDesc InjectErrorMap[] = 
{
	Declare_Error(OK)
	Declare_Error(Error_NoSuchFile)
	Declare_Error(Error_OpenProcess)
	Declare_Error(Error_HeapAlloc)
	Declare_Error(Error_VirtualAllocEx)
	Declare_Error(Error_GetProcAddress)
	Declare_Error(Error_WriteProcessMemory)
	Declare_Error(Error_CreateRemoteThread)
};

wchar_t* GetInjectErrorDesc(int code)
{
	for (int i = 0; i < sizeof(InjectErrorMap) / sizeof(InjectErrorMap[0]); i++)
	{
		if ( code == InjectErrorMap[i].code)
		{
			return InjectErrorMap[i].des;
		}
	}
	return NULL;
}


bool g_b_64bitos = false;
bool g_b_64bitos_init = false;

bool Is64BitOS()
{
	if (g_b_64bitos_init)
		return g_b_64bitos;

	typedef VOID (WINAPI *LPFN_GetNativeSystemInfo)( __out LPSYSTEM_INFO lpSystemInfo );
	LPFN_GetNativeSystemInfo fnGetNativeSystemInfo = (LPFN_GetNativeSystemInfo)GetProcAddress( GetModuleHandleW(L"kernel32"),"GetNativeSystemInfo");
	if(fnGetNativeSystemInfo)
	{
		SYSTEM_INFO stInfo = {0};
		fnGetNativeSystemInfo( &stInfo);
		if( stInfo.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_IA64
			|| stInfo.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_AMD64)
		{
			g_b_64bitos = true;
		}
	}
	g_b_64bitos_init = true;
	return g_b_64bitos;
}

bool Is64BitProcess(DWORD dwPid)
{
	if (!Is64BitOS())
	{
		return false;
	}

	HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION,FALSE,dwPid);
	if(hProcess)
	{
		typedef BOOL (WINAPI *LPFN_ISWOW64PROCESS) (HANDLE, PBOOL);
		LPFN_ISWOW64PROCESS fnIsWow64Process = (LPFN_ISWOW64PROCESS)GetProcAddress( GetModuleHandleW(L"kernel32"),"IsWow64Process");
		if (NULL != fnIsWow64Process)
		{
			BOOL bIsWow64 = FALSE;
			fnIsWow64Process(hProcess,&bIsWow64);
			CloseHandle(hProcess);
			return !bIsWow64;
		}
	}
	return false;
}

std::string w2a(const wchar_t* szIn)
{
	int nSize = WideCharToMultiByte(CP_ACP, 0, szIn, -1, NULL, NULL, NULL, NULL);
	char* buffer = new char[nSize+1];
	ZeroMemory(buffer,nSize+1);
	WideCharToMultiByte(CP_ACP, 0, szIn, -1, buffer, nSize, NULL, NULL);
	std::string strRet(buffer);
	delete[] buffer;
	return strRet;
}

std::wstring a2w(const char* szIn)
{
	int length = MultiByteToWideChar(CP_ACP, 0, szIn, -1, NULL, 0);
	WCHAR* buf = new WCHAR[length+1];
	ZeroMemory(buf, (length + 1) * sizeof(WCHAR));
	MultiByteToWideChar(CP_ACP, 0, szIn, -1, buf, length);
	std::wstring strRet(buf);
	delete[] buf;
	return strRet;
}