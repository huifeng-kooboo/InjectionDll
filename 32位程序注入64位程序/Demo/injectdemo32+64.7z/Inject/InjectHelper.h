#pragma once

void InjectHelper(DWORD dwPid, const char* szDllname86, const char* szDllname64, const char* szFunName, const char* szParam, bool bLoadDll, bool bUnloadDll);