#include "stdafx.h"
#include "InjectHelper32.h"


#define FillInString(addr, str)	\
	addr =  targetAddress + currentIdx;	\
	dwTmp = (DWORD)strlen(str) + 1;	\
	memcpy(currentAddress + currentIdx, str, dwTmp);	\
	currentIdx += dwTmp;

/* This is the way the following assembly code would look like in C/C++

// Load the injected DLL into this process
HMODULE h = GetModuleHandleA("xxx.dll");
if(h)
{
FARPROC p = GetProcAddress(h, "xxx");
if (p)
{
__asm call p(xxx)
}
}
ExitThread(0);
*/
unsigned char injectCode_Head_Silent[] = {
	0x68, 0x00, 0x00, 0x00, 0x00,		// 0	PUSH {injectDllNameAddr}	:"inject.dll"
	0xB8, 0x00, 0x00, 0x00, 0x00,		// 5	MOV EAX, {FARPROC_LoadLibraryA}
	0xFF, 0xD0,							// 10	CALL EAX					:Call LoadLibraryA
	0x83, 0xF8,	0x00,					// 12	CMP EAX, 0
	0x74, 0x1E,							// 15	JZ EIP + 0x1E : skip over nRetor code
	0xA3, 0x00, 0x00, 0x00, 0x00,		// 17	MOV [injectDllAddr], EAX	:����mutehook.dll�ĵ�ַ
	0x68, 0x00, 0x00, 0x00, 0x00,		// 22	PUSH {injectFuncNameAddr}	:inject.dll�ĵ�������
	0x50,								// 27	Push EAX					:
	0xB8, 0x00, 0x00, 0x00, 0x00,		// 28	MOV EAX, {FARPROC_GetProcAddress}
	0xFF, 0xD0,							// 33	CALL EAX					:Call GetProcAddress
	0x83, 0xF8,	0x00,					// 35	CMP EAX, 0
	0x74, 0x07,							// 38	JZ EIP+ 0x07 : go to exit
	0x68, 0x00, 0x00, 0x00, 0x00,		// 40	PUSH [injectParamAddr]		:���������Ĳ���
	0xFF, 0xD0,							// 45	CALL EAX					:Call ��������
};

/* This is the way the following assembly code would look like in C/C++

// Load the injected DLL into this process
HMODULE h = LoadLibrary("mydll.dll");
if(!h)
{
	MessageBox(0, "Could not load the dll: mydll.dll", "Error", MB_ICONERROR);
	ExitThread(0);
}

// Get the address of the export function
FARPROC p = GetProcAddress(h, "Initialize");
if(!p)
{
	MessageBox(0, "Could not load the function: Initialize", "Error", MB_ICONERROR);
	ExitThread(0);
}

// So we do not need a function pointer interface
__asm call p

// Exit the thread so the loader continues
ExitThread(0);
*/
unsigned char injectCode_Head_NoSilent[] = {
	0x68, 0x00, 0x00, 0x00, 0x00,		// 0	PUSH {user32NameAddr}		:"user32.dll"
	0xB8, 0x00, 0x00, 0x00, 0x00,		// 5	MOV EAX, {FARPROC_LoadLibraryA}
	0xFF, 0xD0,							// 10	CALL EAX					:Call LoadLibraryA
	0x68, 0x00, 0x00, 0x00, 0x00,		// 12	PUSH {msgboxNameAddr}		:"MessageBoxA"
	0x50,								// 17	Push EAX
	0xB8, 0x00, 0x00, 0x00, 0x00,		// 18	MOV EAX, {FARPROC_GetProcAddress}
	0xFF, 0xD0,							// 23	CALL EAX					:Call GetProcAddress
	0xA3, 0x00, 0x00, 0x00, 0x00,		// 25	MOV [msgboxAddr], EAX
	0x68, 0x00, 0x00, 0x00, 0x00,		// 30	PUSH {injectDllNameAddr}	:"inject.dll"
	0xB8, 0x00, 0x00, 0x00, 0x00,		// 35	MOV EAX, {FARPROC_LoadLibraryA}
	0xFF, 0xD0,							// 40	CALL EAX					:Call LoadLibraryA
	0x83, 0xF8,	0x00,					// 42	CMP EAX, 0
	0x75, 0x1E,							// 45	JNZ EIP + 0x1E : skip over nRetor code
	0x6A, 0x10,							// 47	PUSH 0x10					:MB_ICONHAND
	0x68, 0x00, 0x00, 0x00, 0x00,		// 49	PUSH {injectErrorTitleAddr}	:MessageBox title
	0x68, 0x00, 0x00, 0x00, 0x00,		// 54	PUSH {injectErrorMsg1Addr}	:MessageBox message
	0x6A, 0x00,							// 59	PUSH 0						:HWND
	0xA1, 0x00, 0x00, 0x00, 0x00,		// 61	MOV EAX, [msgboxAddr]
	0xFF, 0xD0,							// 66	CALL EAX					:Call MessageBoxA
	0x6A, 0x00,							// 68	PUSH 0						
	0xB8, 0x00, 0x00, 0x00, 0x00,		// 70	MOV EAX, [exitthread]
	0xFF, 0xD0,							// 75	CALL EAX					:Call ExitThread
	0xA3, 0x00, 0x00, 0x00, 0x00,		// 77	MOV [injectDllAddr], EAX	:����mutehook.dll�ĵ�ַ
	0x68, 0x00, 0x00, 0x00, 0x00,		// 82	PUSH {injectFuncNameAddr}	:inject.dll�ĵ�������
	0x50,								// 87	Push EAX					:
	0xB8, 0x00, 0x00, 0x00, 0x00,		// 88	MOV EAX, {FARPROC_GetProcAddress}
	0xFF, 0xD0,							// 93	CALL EAX					:Call GetProcAddress
	0x83, 0xF8,	0x00,					// 95	CMP EAX, 0
	0x75, 0x1C,							// 98	JNZ EIP + 0x1C : skip over nRetor code
	0x6A, 0x10,							// 100	PUSH 0x10					:MB_ICONHAND
	0x68, 0x00, 0x00, 0x00, 0x00,		// 102	PUSH {injectErrorTitleAddr}	:MessageBox title
	0x68, 0x00, 0x00, 0x00, 0x00,		// 107	PUSH {injectErrorMsg2Addr}	:MessageBox message
	0x6A, 0x00,							// 112	PUSH 0						:HWND
	0xA1, 0x00, 0x00, 0x00, 0x00,		// 114	MOV EAX, [msgboxAddr]
	0xFF, 0xD0,							// 119	CALL EAX					:Call MessageBoxA
	0x6A, 0x00,							// 121	PUSH 0						
	0xB8, 0x00, 0x00, 0x00, 0x00,		// 123	MOV EAX, [exitthread]
	0x68, 0x00, 0x00, 0x00, 0x00,		// 128	PUSH [injectParamAddr]		:���������Ĳ���
	0xFF, 0xD0,							// 133	CALL EAX					:Call ExitThread���ߵ�������
};

unsigned char injectCode_Tail_FreeLibraryAndET[] = {
	0x6A, 0x00,								// 0	Push 0
	0xFF, 0x35, 0x00, 0x00, 0x00, 0x00,		// 2	PUSH [injectDllAddr]
	0xB8, 0x00, 0x00, 0x00, 0x00,			// 8	MOV EAX, {FARPROC_FreeLibraryAndExitThread}
	0xFF, 0xD0,								// 13	CALL EAX				:Call FreeLibraryAndExitThread
};

unsigned char injectCode_Tail_ExitThread[] = {
	0x6A, 0x00,								// 0	PUSH 0						
	0xB8, 0x00, 0x00, 0x00, 0x00,			// 2	MOV EAX, [exitthread]
	0xFF, 0xD0,								// 12	CALL EAX				:Call ExitThread
};

InjectResult Inject32Silent(DWORD dwPid, const char* dllname, const char* funcname, const char* param, bool bLoadDll, bool bUnloadDll)
{
	InjectResult nRet = OK;
	LPVOID targetWorkspace	= NULL;
	LPBYTE currentAddress	= NULL;
	HANDLE hProcess = NULL;
	HANDLE hThread = NULL;
	
	do 
	{
		// Step1. OpenProcess
		hProcess = OpenProcess(
			PROCESS_QUERY_INFORMATION |   // Required by Alpha
			PROCESS_CREATE_THREAD     |   // For CreateRemoteThread
			PROCESS_VM_OPERATION      |   // For VirtualAllocEx/VirtualFreeEx
			PROCESS_VM_WRITE,             // For WriteProcessMemory
			FALSE, dwPid);

		if (NULL == hProcess)
		{
			nRet = Error_OpenProcess;
			break;
		}

		// Step2. Create the currentAddress
		currentAddress = (LPBYTE)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, 1024);
		if (NULL == currentAddress)
		{
			nRet = Error_HeapAlloc;
			break;
		}

		// Step3. Allocate space for the codecave in the process
		targetWorkspace = VirtualAllocEx(hProcess, 0, 1024, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
		if (NULL == targetWorkspace)
		{
			nRet = Error_VirtualAllocEx;
			break;
		}

		DWORD targetAddress = PtrToUlong(targetWorkspace);

		// Step4. Prepare machine codes to run in target process

		// 4.1. ��ȡһЩ�����ĵ�ַ
		HMODULE kernel32	= LoadLibraryA("kernel32.dll");
		FARPROC loadlibrary		= GetProcAddress(kernel32,	bLoadDll ? "LoadLibraryA" : "GetModuleHandleA");
		FARPROC getprocaddress	= GetProcAddress(kernel32,	"GetProcAddress");
		FARPROC exitthread		= GetProcAddress(kernel32,	"ExitThread");
		FARPROC freelibraryandexitthread = GetProcAddress(kernel32,	"FreeLibraryAndExitThread");

		// ����
		DWORD currentIdx	= 0;
		DWORD dwTmp = 0;

		// 4.2. ���һ��ָ��ռ�
		size_t sizePtr = sizeof(int*);
		const size_t addressCount = 1;
		for (size_t i = 0 ; i < addressCount * sizePtr; i++)
		{
			currentAddress[i] = 0x00;
		}
		currentIdx += addressCount * sizePtr;		// �ƽ�����
		DWORD injectDllAddr = targetAddress + 0;	// ��Ŵ�ע���dll�ļ��ص�ַ

		// 4.3. ����ַ���
		char injectDllName[MAX_PATH + 1]	= {0};
		char injectFuncName[MAX_PATH + 1]	= {0};
		char injectParam[MAX_PATH*2 + 1]	= {0};
		_snprintf_s(injectDllName, MAX_PATH, MAX_PATH -1, "%s", dllname);
		_snprintf_s(injectFuncName, MAX_PATH, MAX_PATH -1, "%s", funcname);
		_snprintf_s(injectParam, MAX_PATH*2, MAX_PATH*2 -1, "%s", param);

		DWORD injectDllNameAddr		= 0;
		DWORD injectFuncNameAddr	= 0;
		DWORD injectParamAddr		= 0;
		FillInString(injectDllNameAddr, injectDllName)
		FillInString(injectFuncNameAddr, injectFuncName)
		FillInString(injectParamAddr, injectParam)


		// 4.4. ���һЩint3���ָ��ַ������ʹ�����
		const size_t int3_count = 3;
		for (size_t i = 0 ; i < int3_count; i++)
		{
			currentAddress[currentIdx++] = 0xCC;
		}

		// 4.5 ���������Ĵ��뿪ʼλ��
		DWORD targetExcuteCodeAddress =  targetAddress + currentIdx;

		// 4.6. ����������
		memcpy(injectCode_Head_Silent + 1, &injectDllNameAddr, 4);
		memcpy(injectCode_Head_Silent + 6, &loadlibrary, 4);
		memcpy(injectCode_Head_Silent + 18, &injectDllAddr, 4);
		memcpy(injectCode_Head_Silent + 23, &injectFuncNameAddr, 4);
		memcpy(injectCode_Head_Silent + 29, &getprocaddress, 4);
		memcpy(injectCode_Head_Silent + 41, &injectParamAddr, 4);
		memcpy(currentAddress + currentIdx, injectCode_Head_Silent ,sizeof(injectCode_Head_Silent));
		currentIdx += sizeof(injectCode_Head_Silent);

		if (bUnloadDll)
		{
			memcpy(injectCode_Tail_FreeLibraryAndET + 4, &injectDllAddr, 4);
			memcpy(injectCode_Tail_FreeLibraryAndET + 9, &freelibraryandexitthread, 4);
			memcpy(currentAddress + currentIdx, injectCode_Tail_FreeLibraryAndET ,sizeof(injectCode_Tail_FreeLibraryAndET));
			currentIdx += sizeof(injectCode_Tail_FreeLibraryAndET);
		}
		else
		{
			memcpy(injectCode_Tail_ExitThread + 3, &exitthread, 4);
			memcpy(currentAddress + currentIdx, injectCode_Tail_ExitThread ,sizeof(injectCode_Tail_ExitThread));
			currentIdx += sizeof(injectCode_Tail_ExitThread);
		}


		// Step5. Change page protection so we can write executable code
		DWORD oldProtect	= 0;	
		VirtualProtectEx(hProcess, targetWorkspace, currentIdx, PAGE_EXECUTE_READWRITE, &oldProtect);

		// Step6. Write out the patch
		DWORD bytesRet		= 0;
		if (!WriteProcessMemory(hProcess, targetWorkspace, currentAddress, currentIdx, &bytesRet))
		{
			nRet = Error_WriteProcessMemory;
			break;
		}

		// Step7. Restore page protection
		VirtualProtectEx(hProcess, targetWorkspace, currentIdx, oldProtect, &oldProtect);

		// Step8. Make sure our changes are written right away
		FlushInstructionCache(hProcess, targetWorkspace, currentIdx);

		// Step9. Execute the thread now and wait for it to exit, note we execute where the code starts, and not the codecave start
		// (since we wrote strings at the start of the codecave) -- NOTE: void* used for VC6 compatibility instead of UlongToPtr
		hThread = CreateRemoteThread(hProcess, NULL, 0, (LPTHREAD_START_ROUTINE)((void*)targetExcuteCodeAddress), 0, 0, NULL);
		if (NULL == hThread)
		{
			nRet = Error_CreateRemoteThread;
			break;
		}
		WaitForSingleObject(hThread, INFINITE); 

	} while (0);

	// Step10. Cleanup
	if (hProcess)
	{
		CloseHandle(hProcess);
	}

	if (hThread)
	{
		CloseHandle(hThread);
	}

	// Free the memory in the process that we allocated
	if (targetWorkspace)
	{
		VirtualFreeEx(hProcess, targetWorkspace, 0, MEM_RELEASE);
	}

	// Free the currentAddress memory
	if (currentAddress)
	{
		HeapFree(GetProcessHeap(), 0, currentAddress);
	}

	return nRet;
}

InjectResult Inject32WithErrorPrompt(DWORD dwPid, const char* dllname, const char* funcname, const char* param, bool bLoadDll, bool bUnloadDll)
{
	InjectResult nRet = OK;
	LPVOID targetWorkspace	= NULL;
	LPBYTE currentAddress	= NULL;
	HANDLE hProcess = NULL;
	HANDLE hThread = NULL;

	do 
	{
		// Step1. OpenProcess
		hProcess = OpenProcess(
			PROCESS_QUERY_INFORMATION |   // Required by Alpha
			PROCESS_CREATE_THREAD     |   // For CreateRemoteThread
			PROCESS_VM_OPERATION      |   // For VirtualAllocEx/VirtualFreeEx
			PROCESS_VM_WRITE,             // For WriteProcessMemory
			FALSE, dwPid);

		if (NULL == hProcess)
		{
			nRet = Error_OpenProcess;
			break;
		}

		// Step2. Create the currentAddress
		currentAddress = (LPBYTE)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, 1024);
		if (NULL == currentAddress)
		{
			nRet = Error_HeapAlloc;
			break;
		}

		// Step3. Allocate space for the codecave in the process
		targetWorkspace = VirtualAllocEx(hProcess, 0, 1024, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
		if (NULL == targetWorkspace)
		{
			nRet = Error_VirtualAllocEx;
			break;
		}

		DWORD targetAddress = PtrToUlong(targetWorkspace);

		// Step4. Prepare machine codes to run in target process

		// 4.1. ��ȡһЩ�����ĵ�ַ
		HMODULE kernel32	= LoadLibraryA("kernel32.dll");
		FARPROC loadlibrary		= GetProcAddress(kernel32,	bLoadDll ? "LoadLibraryA" : "GetModuleHandleA");
		FARPROC getprocaddress	= GetProcAddress(kernel32,	"GetProcAddress");
		FARPROC exitthread		= GetProcAddress(kernel32,	"ExitThread");
		FARPROC freelibraryandexitthread = GetProcAddress(kernel32,	"FreeLibraryAndExitThread");

		// ����
		DWORD currentIdx	= 0;
		DWORD dwTmp = 0;

		// 4.2. �������ָ��ռ�
		size_t sizePtr = sizeof(int*);
		const size_t addressCount = 3;
		for (size_t i = 0 ; i < addressCount * sizePtr; i++)
		{
			currentAddress[i] = 0x00;
		}
		currentIdx += addressCount * sizePtr;		// �ƽ�����

		DWORD user32Addr = targetAddress + 0;		// ���User32.dll��ģ���ַ
		DWORD msgboxAddr = targetAddress + 4;		// ���User32.dll��MessageBoxA��ģ���ַ
		DWORD injectDllAddr = targetAddress + 8;	// ��Ŵ�ע���dll�ļ��ص�ַ

		// 4.3. ����ַ���
		char user32Name[MAX_PATH + 1]		= {0};
		char msgboxName[MAX_PATH + 1]		= {0};
		char injectDllName[MAX_PATH + 1]	= {0};
		char injectFuncName[MAX_PATH + 1]	= {0};
		char injectParam[MAX_PATH*2 + 1]		= {0};
		char injectErrorTitle[MAX_PATH + 1]		= {0};
		char injectErrorMsg1[MAX_PATH + 1]		= {0};
		char injectErrorMsg2[MAX_PATH + 1]		= {0};
		_snprintf_s(injectDllName, MAX_PATH, MAX_PATH-1, "%s", dllname);
		_snprintf_s(injectFuncName, MAX_PATH, MAX_PATH-1, "%s", funcname);
		_snprintf_s(injectParam, MAX_PATH*2, MAX_PATH*2-1, "%s", param);
		_snprintf_s(user32Name, MAX_PATH, MAX_PATH-1, "user32.dll");
		_snprintf_s(msgboxName, MAX_PATH, MAX_PATH-1, "MessageBoxA");
		_snprintf_s(injectErrorTitle, MAX_PATH, MAX_PATH-1, "Error");
		_snprintf_s(injectErrorMsg1, MAX_PATH, MAX_PATH-1, "Could not load the dll: %s", injectDllName);
		_snprintf_s(injectErrorMsg2, MAX_PATH, MAX_PATH-1, "Could not load the function: %s", injectFuncName);

		DWORD user32NameAddr	= 0;
		DWORD msgboxNameAddr	= 0;
		DWORD injectDllNameAddr		= 0;
		DWORD injectFuncNameAddr		= 0;
		DWORD injectParamAddr		= 0;
		DWORD injectErrorTitleAddr		= 0;
		DWORD injectErrorMsg1Addr		= 0;
		DWORD injectErrorMsg2Addr		= 0;
		FillInString(user32NameAddr, user32Name)
		FillInString(msgboxNameAddr, msgboxName)
		FillInString(injectDllNameAddr, injectDllName)
		FillInString(injectFuncNameAddr, injectFuncName)
		FillInString(injectParamAddr, injectParam)
		FillInString(injectErrorTitleAddr, injectErrorTitle)
		FillInString(injectErrorMsg1Addr, injectErrorMsg1)
		FillInString(injectErrorMsg2Addr, injectErrorMsg2)

		// 4.4. ���һЩint3���ָ��ַ������ʹ�����
		const size_t int3_count = 3;
		for (size_t i = 0 ; i < int3_count; i++)
		{
			currentAddress[currentIdx++] = 0xCC;
		}

		// 4.5 ���������Ĵ��뿪ʼλ��
		DWORD targetExcuteCodeAddress =  targetAddress + currentIdx;

		// 4.6. ����������
		memcpy(injectCode_Head_NoSilent + 1, &user32NameAddr, 4);
		memcpy(injectCode_Head_NoSilent + 6, &loadlibrary, 4);
		memcpy(injectCode_Head_NoSilent + 13, &msgboxNameAddr, 4);
		memcpy(injectCode_Head_NoSilent + 19, &getprocaddress, 4);
		memcpy(injectCode_Head_NoSilent + 26, &msgboxAddr, 4);
		memcpy(injectCode_Head_NoSilent + 31, &injectDllNameAddr, 4);
		memcpy(injectCode_Head_NoSilent + 36, &loadlibrary, 4);
		memcpy(injectCode_Head_NoSilent + 50, &injectErrorTitleAddr, 4);
		memcpy(injectCode_Head_NoSilent + 55, &injectErrorMsg1Addr, 4);
		memcpy(injectCode_Head_NoSilent + 62, &msgboxAddr, 4);
		memcpy(injectCode_Head_NoSilent + 71, &exitthread, 4);
		memcpy(injectCode_Head_NoSilent + 78, &injectDllAddr, 4);
		memcpy(injectCode_Head_NoSilent + 83, &injectFuncNameAddr, 4);
		memcpy(injectCode_Head_NoSilent + 89, &getprocaddress, 4);
		memcpy(injectCode_Head_NoSilent + 103, &injectErrorTitleAddr, 4);
		memcpy(injectCode_Head_NoSilent + 108, &injectErrorMsg2Addr, 4);
		memcpy(injectCode_Head_NoSilent + 115, &msgboxAddr, 4);
		memcpy(injectCode_Head_NoSilent + 124, &exitthread, 4);
		memcpy(injectCode_Head_NoSilent + 129, &injectParamAddr, 4);
		memcpy(currentAddress + currentIdx, injectCode_Head_NoSilent ,sizeof(injectCode_Head_NoSilent));
		currentIdx += sizeof(injectCode_Head_NoSilent);

		if (bUnloadDll)
		{
			memcpy(injectCode_Tail_FreeLibraryAndET + 4, &injectDllAddr, 4);
			memcpy(injectCode_Tail_FreeLibraryAndET + 9, &freelibraryandexitthread, 4);
			memcpy(currentAddress + currentIdx, injectCode_Tail_FreeLibraryAndET ,sizeof(injectCode_Tail_FreeLibraryAndET));
			currentIdx += sizeof(injectCode_Tail_FreeLibraryAndET);
		}
		else
		{
			memcpy(injectCode_Tail_ExitThread + 3, &exitthread, 4);
			memcpy(currentAddress + currentIdx, injectCode_Tail_ExitThread ,sizeof(injectCode_Tail_ExitThread));
			currentIdx += sizeof(injectCode_Tail_ExitThread);
		}

		// Step5. Change page protection so we can write executable code
		DWORD oldProtect	= 0;	
		VirtualProtectEx(hProcess, targetWorkspace, currentIdx, PAGE_EXECUTE_READWRITE, &oldProtect);

		// Step6. Write out the patch
		DWORD bytesRet		= 0;
		if (!WriteProcessMemory(hProcess, targetWorkspace, currentAddress, currentIdx, &bytesRet))
		{
			nRet = Error_WriteProcessMemory;
			break;
		}

		// Step7. Restore page protection
		VirtualProtectEx(hProcess, targetWorkspace, currentIdx, oldProtect, &oldProtect);

		// Step8. Make sure our changes are written right away
		FlushInstructionCache(hProcess, targetWorkspace, currentIdx);

		// Step9. Execute the thread now and wait for it to exit, note we execute where the code starts, and not the codecave start
		// (since we wrote strings at the start of the codecave) -- NOTE: void* used for VC6 compatibility instead of UlongToPtr
		hThread = CreateRemoteThread(hProcess, NULL, 0, (LPTHREAD_START_ROUTINE)((void*)targetExcuteCodeAddress), 0, 0, NULL);
		if (NULL == hThread)
		{
			nRet = Error_CreateRemoteThread;
			break;
		}
		WaitForSingleObject(hThread, INFINITE); 

	} while (0);


	// Step10. Cleanup
	if (hProcess)
	{
		CloseHandle(hProcess);
	}

	if (hThread)
	{
		CloseHandle(hThread);
	}

	// Free the memory in the process that we allocated
	if (targetWorkspace)
	{
		VirtualFreeEx(hProcess, targetWorkspace, 0, MEM_RELEASE);
	}

	// Free the currentAddress memory
	if (currentAddress)
	{
		HeapFree(GetProcessHeap(), 0, currentAddress);
	}
	return nRet;
}