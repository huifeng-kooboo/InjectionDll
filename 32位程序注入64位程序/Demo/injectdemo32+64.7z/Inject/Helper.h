#pragma once
#include <iostream>

enum  InjectResult
{
	OK,
	Error_NoSuchFile,
	Error_OpenProcess,
	Error_HeapAlloc,
	Error_VirtualAllocEx,
	Error_GetProcAddress,
	Error_WriteProcessMemory,
	Error_CreateRemoteThread
};
wchar_t* GetInjectErrorDesc(int code);

std::string w2a(const wchar_t* szIn);
std::wstring a2w(const char* szIn);

bool Is64BitOS();
bool Is64BitProcess(DWORD dwPid);