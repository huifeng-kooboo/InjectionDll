#include "stdafx.h"
#include "InjectHelper64.h"
#include "../Wow64Ext/wow64ext.h"
#pragma comment(lib,"wow64ext.lib")


#define __STR2WSTR(str)    L##str
#define _STR2WSTR(str)     __STR2WSTR(str)
#define __FUNCTIONW__      _STR2WSTR(__FUNCTION__)


unsigned char injectcode_loaddll[] = {
	0x48, 0x89, 0x4c, 0x24, 0x08,                               // mov       qword ptr [rsp+8],rcx 
	0x57,                                                       // push      rdi
	0x48, 0x83, 0xec, 0x20,                                     // sub       rsp,20h
	0x48, 0x8b, 0xfc,                                           // mov       rdi,rsp
	0xb9, 0x08, 0x00, 0x00, 0x00,                               // mov       ecx,8
	0xb8, 0xcc, 0xcc, 0xcc, 0xcc,                               // mov       eac,0CCCCCCCCh
	0xf3, 0xab,                                                 // rep stos  dword ptr [rdi]
	0x48, 0x8b, 0x4c, 0x24, 0x30,                               // mov       rcx,qword ptr [__formal]
	0x49, 0xb9, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // mov       r9,0  //PVOID*  BaseAddr opt
	0x49, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // mov       r8,0  //PUNICODE_STRING Name
	0x48, 0xba, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // mov       rdx,0
	0x48, 0xb9, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // mov       rcx,0
	0x48, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // mov       rax,0 
	0xff, 0xd0,                                                 // call      rax   LdrLoadDll
	0x48, 0xb9, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // mov       rcx,0
	0x48, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // mov       rax,0
	0xff, 0xd0                                                  // call      rax
};

unsigned char injectcode_silent[] = {
	0x48, 0x89, 0x4c, 0x24, 0x08,                               // 0	mov       qword ptr [rsp+8],rcx 
	0x57,                                                       // 5	push      rdi
	0x48, 0x83, 0xec, 0x20,                                     // 6	sub       rsp,20h
	0x48, 0x8b, 0xfc,                                           // 10	mov       rdi,rsp
	0xb9, 0x08, 0x00, 0x00, 0x00,                               // 13	mov       ecx,8
	0xb8, 0xcc, 0xcc, 0xcc, 0xcc,                               // 18	mov       eac,0CCCCCCCCh
	0xf3, 0xab,                                                 // 23	rep stos  dword ptr [rdi]
	0x48, 0x8b, 0x4c, 0x24, 0x30,                               // 25	mov       rcx,qword ptr [__formal]

	// ����dll
	0x49, 0xb9, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 30	mov       r9,0  //PVOID*  DllBaseAddr opt
	0x49, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 40	mov       r8,0  //PUNICODE_STRING Name
	0x48, 0xba, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 50	mov       rdx,0
	0x48, 0xb9, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 60	mov       rcx,0
	0x48, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 70	mov       rax,0 
	0xff, 0xd0,                                                 // 80	call      rax	Call LdrLoadDll

	// ��ȡdll�к�����ַ
	0x49, 0xb9, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 82	mov       r9,0  
	0x49, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 92	mov       r8,0  
	0x48, 0xba, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 102	mov       rdx,0	//PANSI_STRING Name
	0x48, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 112	mov       rax,	{//PVOID*  DllBaseAddr opt} 
	0x48, 0x8b, 0x00,											// 122	rax,qword ptr [rax]  
	0x48, 0x8b, 0xc8,											// 125	mov       rcx,rax  
	0x48, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 128	mov       rax,0 
	0xff, 0xd0,                                                 // 138	call      rax	Call LdrGetProcedureAddress

	// ����dll�к���
	0x48, 0xb9, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 140	mov       rcx,0
	0x48, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 150	mov       rax,	{//PVOID*  FuncAddr opt} 
	0x48, 0x8b, 0x00,											// 160	rax,qword ptr [rax]  
	0xff, 0xd0,                                                 // 163	call      rax	Call Dll:Fun


	0x48, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 165	mov       rax,0
	0xff, 0xd0                                                  // 175	call      rax	Call RtlExitThread
};

typedef struct _ANSI_STRING {    
	USHORT Length;
	USHORT MaximumLength;
	DWORD64  Buffer;
} ANSI_STRING, *PANSI_STRING;

typedef struct _UNICODE_STRING {
	USHORT    Length;		
	USHORT	  MaximumLength; 
	DWORD64   Buffer;     
} UNICODE_STRING ,*PUNICODE_STRING;


InjectResult Inject64Silent(DWORD dwPid, const wchar_t* szDllName, const char* szFunName, const char* szParam)
{
	HANDLE handle = OpenProcess(PROCESS_ALL_ACCESS,FALSE,dwPid);
	if (INVALID_HANDLE_VALUE == handle)
	{
		return Error_OpenProcess;
	}

	size_t param_length = (size_t)::strlen(szParam);
	size_t param_size = (param_length+1)*sizeof(char);
	DWORD64 param_remoteaddr = (DWORD64)VirtualAllocEx64(handle,NULL,param_size,MEM_COMMIT,PAGE_READWRITE);

	size_t dll_length = (size_t)::_tcslen(szDllName);
	size_t dll_size = (dll_length+1)*sizeof(TCHAR) + sizeof(UNICODE_STRING) + sizeof(DWORD64);
	DWORD64 dll_remoteaddr = (DWORD64)VirtualAllocEx64(handle,NULL,dll_size,MEM_COMMIT,PAGE_READWRITE);

	size_t func_length = (size_t)::strlen(szFunName);
	size_t func_size = (func_length+1)*sizeof(char) + sizeof(ANSI_STRING) + sizeof(DWORD64);
	DWORD64 func_remoteaddr = (DWORD64)VirtualAllocEx64(handle,NULL,func_size,MEM_COMMIT,PAGE_READWRITE);

	DWORD64  shell_code_addr = (DWORD64)VirtualAllocEx64(handle,NULL,sizeof(injectcode_silent),MEM_COMMIT,PAGE_EXECUTE_READWRITE);
	if ((!dll_remoteaddr) || (!func_remoteaddr)  || (!param_remoteaddr) || (!shell_code_addr))
	{
		return Error_VirtualAllocEx;
	}

	char * dll_localaddr = new char[dll_size];
	memset(dll_localaddr,0,dll_size);
	PUNICODE_STRING ptr_unicode_string = (PUNICODE_STRING)(dll_localaddr + sizeof(DWORD64));
	ptr_unicode_string->Length = dll_length*2;
	ptr_unicode_string->MaximumLength = dll_length*2+2;
	wcscpy((WCHAR*)(ptr_unicode_string+1),szDllName);
	ptr_unicode_string->Buffer = (DWORD64)((char*)dll_remoteaddr+sizeof(DWORD64)+sizeof(UNICODE_STRING));

	char * func_localaddr = new char[func_size];
	memset(func_localaddr,0,func_size);
	PANSI_STRING ptr_ansi_string = (PANSI_STRING)(func_localaddr + sizeof(DWORD64));
	ptr_ansi_string->Length = func_length*1;
	ptr_ansi_string->MaximumLength = func_length*1+1;
	strcpy((char*)(ptr_ansi_string+1),szFunName);
	ptr_ansi_string->Buffer = (DWORD64)((char*)func_remoteaddr+sizeof(DWORD64)+sizeof(ANSI_STRING));

	char * param_localaddr = new char[param_size];
	memset(param_localaddr,0,param_size);
	strcpy((char*)(param_localaddr),szParam);

	DWORD64 ntdll64 = GetModuleHandle64(L"ntdll.dll");
	DWORD64 ntdll_LdrLoadDll = GetProcAddress64(ntdll64,"LdrLoadDll");
	DWORD64 ntdll_RtlCreateUserThread = GetProcAddress64(ntdll64,"RtlCreateUserThread");
	DWORD64 ntdll_RtlExitThread = GetProcAddress64(ntdll64,"RtlExitUserThread");
	DWORD64 ntdll_LdrGetProcedureAddress = GetProcAddress64(ntdll64,"LdrGetProcedureAddress");
	if (NULL == ntdll_LdrLoadDll || NULL==ntdll_RtlCreateUserThread || NULL==ntdll_RtlExitThread || NULL==ntdll_LdrGetProcedureAddress)
	{
		return Error_GetProcAddress;
	}
	//r9 returnVal: dll��ַ����ֵ��������
	memcpy(injectcode_silent+32,&dll_remoteaddr,sizeof(DWORD64));

	//r8 dll����
	DWORD64 ptr = dll_remoteaddr+sizeof(DWORD64);
	memcpy(injectcode_silent+42,&ptr,sizeof(PUNICODE_STRING));

	//Call LdrLoaddll
	memcpy(injectcode_silent+72,&ntdll_LdrLoadDll,sizeof(DWORD64));

	//r9 returnVal: ������ַ����ֵ��������
	memcpy(injectcode_silent+84,&func_remoteaddr,sizeof(DWORD64));

	//rcx dll������
	ptr = func_remoteaddr+sizeof(DWORD64);
	memcpy(injectcode_silent+104,&ptr,sizeof(PANSI_STRING));

	//rcx ��dll��ַ��Ϊ��������LdrGetProcedureAddress
	ptr = dll_remoteaddr;
	memcpy(injectcode_silent+114,&ptr,sizeof(DWORD64));

	//Call LdrGetProcedureAddress
	memcpy(injectcode_silent+130,&ntdll_LdrGetProcedureAddress,sizeof(DWORD64));

	// ��������
	ptr = param_remoteaddr;
	memcpy(injectcode_silent+142,&ptr,sizeof(DWORD64));

	//Call dll�еĺ���
	ptr = func_remoteaddr;
	memcpy(injectcode_silent+152,&ptr,sizeof(DWORD64));

	//RtlExitUserThread
	memcpy(injectcode_silent+167,&ntdll_RtlExitThread,sizeof(DWORD64));
	size_t write_size = 0;
	if (!WriteProcessMemory64(handle,dll_remoteaddr,dll_localaddr,dll_size,NULL) ||
		!WriteProcessMemory64(handle,func_remoteaddr,func_localaddr,func_size,NULL) ||
		!WriteProcessMemory64(handle,param_remoteaddr,param_localaddr,param_size,NULL) ||
		!WriteProcessMemory64(handle,shell_code_addr,injectcode_silent,sizeof(injectcode_silent),NULL))
	{
		return Error_WriteProcessMemory;
	}
	DWORD64 hRemoteThread = 0;
	struct {
		DWORD64 UniqueProcess;
		DWORD64 UniqueThread;
	} client_id;
	int a = X64Call(ntdll_RtlCreateUserThread,10,
		(DWORD64)handle,					// ProcessHandle
		(DWORD64)NULL,                      // SecurityDescriptor
		(DWORD64)FALSE,                     // CreateSuspended
		(DWORD64)0,                         // StackZeroBits
		(DWORD64)NULL,                      // StackReserved
		(DWORD64)NULL,                      // StackCommit
		shell_code_addr,					// StartAddress
		(DWORD64)NULL,                      // StartParameter
		(DWORD64)&hRemoteThread,            // ThreadHandle
		(DWORD64)&client_id);               // ClientID)
	if (INVALID_HANDLE_VALUE == (HANDLE)hRemoteThread)
	{
		return Error_CreateRemoteThread;
	}
	return OK;
}


unsigned char injectcode_nosilent[] = {
	0xff, 0xd0                                                  // 175	call      rax	Call RtlExitThread
};


InjectResult Inject64WithErrorPrompt(DWORD dwPid, const wchar_t* szDllName, const char* szFunName, const char* szParam)
{

	return OK;
}


