// Win64VS2008.cpp : ����Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include "Win64VS2008.h"

INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);

void test(__int64 dw)
{
}

void LearnX64MachineCode()
{
	// 	FreeLibrary(LoadLibraryW(L"MsgHook.dll"));

	__int64* i1 = new __int64(0x1111111111111111);
	__int64* i2 = new __int64(0x2222222222222222);
	__int64* i3 = new __int64(0x3333333333333333);
	__int64* i4 = new __int64(0x4444444444444444);
	__int64* i5 = new __int64(0x5555555555555555);
	__int64 i6 = *(reinterpret_cast<__int64*>(0x1122334455667788));
	test(*i1);
	test(*i2);
	test(*i3);
	test(*i4);
	test(*i5);
}

__int64 GetCode()
{
	__int64 i = 0;
	__int64 j =  0;
	for (; i < 10; i++)
	{
		OutputDebugStringA("aass");
		 i = i+i;
	}
	for (; i < 100; i++)
	{	OutputDebugStringA("aass");

		j = i*200;
	}
	for (; i < 1000; i++)
	{
		OutputDebugStringA("aass");

		j = j-300;
	}
	return i;
}
__int64* pi = NULL;
int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
// 	*pi = GetCode();
	DialogBox(hInstance, MAKEINTRESOURCE(IDD_ABOUTBOX), NULL, About);
	return 0;
}

BOOL FilterMsg(UINT uMsg)
{
	switch (uMsg)
	{
	case WM_SIZE:
	case WM_SIZING:
	case WM_WINDOWPOSCHANGED:
	case WM_WINDOWPOSCHANGING:
	case WM_DESTROY:
	case WM_SHOWWINDOW:
		return TRUE;
	default:
		return FALSE;
	}
}

wchar_t* szInject_Class = L"INJECT";
wchar_t* szInject_Name = L"Inject";

BOOL WINAPI HookProc(HWND hwnd,UINT uiMessage, WPARAM wParam,LPARAM lParam)
{
	if (FilterMsg(uiMessage))
	{
		HWND _hWnd = FindWindow(szInject_Class, szInject_Name);
		if (_hWnd)
		{
// 			TCHAR sz[MAX_PATH] = {0};
// 			wsprintf(sz, L"find window 0x%08X", _hWnd);
			LPARAM _lParam = wParam << 16 | uiMessage;
			PostMessage(_hWnd, WM_USER+100, (WPARAM)hwnd, _lParam);
			return TRUE;
		}
	}
	return FALSE;
}

LRESULT CALLBACK SpyGetMsgProc(INT hc,WPARAM wParam,LPARAM lParam)
{
	PMSG pmsg;
	pmsg = (PMSG)lParam;
	if (hc >= 0 && pmsg && pmsg->hwnd)
	{
		/*return*/ HookProc(pmsg->hwnd, pmsg->message, pmsg->wParam, pmsg->lParam);
	}
	return CallNextHookEx(NULL, hc, wParam, lParam);
}

LRESULT CALLBACK SpyCallWndProc(INT hc,WPARAM wParam,LPARAM lParam)
{
	PCWPSTRUCT pcwps;
	pcwps = (PCWPSTRUCT)lParam;
	if (hc >= 0 && pcwps && pcwps->hwnd)
	{
		/*return*/ HookProc(pcwps->hwnd, pcwps->message, pcwps->wParam, pcwps->lParam);
	}
	return CallNextHookEx(NULL, hc, wParam, lParam);
}

// typedef struct stHookInfo
// {
// 	HHOOK hGetMsgHook;
// 	HHOOK hCallWndProcHook;
// 	DWORD dwThreadId;
// 	HWND hWndHook;
// 	HWND hWndCallback;
// 
// 	stHookInfo(){};
// }HookInfo, *PHookInfo;
// 
// HookInfo g_hookInfo;
// 
// BOOL InstallMsgHookWithinProcess()
// {
// 	if (g_hookInfo.hGetMsgHook != NULL)
// 		return FALSE;
// 	
// 	g_hookInfo.hGetMsgHook = SetWindowsHookEx(WH_GETMESSAGE, SpyGetMsgProc, NULL, GetCurrentThreadId());
// 	if (!g_hookInfo.hGetMsgHook)
// 	{
// 		return FALSE;
// 	}
// 
// 	g_hookInfo.hCallWndProcHook = SetWindowsHookEx(WH_CALLWNDPROC, SpyCallWndProc, NULL, GetCurrentThreadId());
// 	if (!g_hookInfo.hCallWndProcHook)
// 	{
// 		UnhookWindowsHookEx(g_hookInfo.hGetMsgHook);
// 		g_hookInfo.hGetMsgHook = NULL;
// 		return FALSE;
// 	}
// 	return TRUE;
// }
// 
// BOOL UninstallMsgHook()
// {	
// 	if (g_hookInfo.hGetMsgHook != NULL)
// 	{	
// 		UnhookWindowsHookEx(g_hookInfo.hGetMsgHook);
// 		g_hookInfo.hGetMsgHook = NULL;
// 	}
// 	if (g_hookInfo.hCallWndProcHook != NULL)
// 	{	
// 		UnhookWindowsHookEx(g_hookInfo.hCallWndProcHook);
// 		g_hookInfo.hCallWndProcHook = NULL;
// 	}
// 	return TRUE;
// }
// 
// #include <stdio.h>
// #include "../msghook/msghook.h"
// // ��Ϣ����DLL
// #pragma comment(lib,"H:\\myvsprj\\myvsprj\\Win64VS2008\\x64\\Debug\\msghook.lib")
// 
// wchar_t* szWin64_Class = L"WIN64VS2008";
// wchar_t* szWin64_Name = L"Win64VS2008";
// 
// BOOL InstallMsgHookInDllWithinProcess()
// {
// 	HWND hWnd = FindWindow(szWin64_Class, szWin64_Name);
// 	DWORD dwThreadId = GetWindowThreadProcessId(hWnd, NULL);
// 	char szParam[200];
// 	sprintf(szParam, "%d", dwThreadId);
// 	SetMsgHookWrapper(szParam);;
// 	return TRUE;
// }


#include "atlconv.h"

const char* lpFileName = "msghook.dll";

typedef struct _ANSI_STRING {	// ANSI_STRING structure     
	USHORT Length;
	USHORT MaximumLength;
	PCHAR  Buffer;
} ANSI_STRING, *PANSI_STRING;

typedef struct _UNICODE_STRING { // UNICODE_STRING structure     
	USHORT Length;    
	USHORT MaximumLength;    
	PWSTR  Buffer;    
} UNICODE_STRING;    
typedef UNICODE_STRING *PUNICODE_STRING;   

typedef LONG NTSTATUS;  

typedef NTSTATUS (WINAPI *fLdrLoadDll)(IN PWCHAR PathToFile OPTIONAL,
									   IN ULONG Flags OPTIONAL,
									   IN PUNICODE_STRING ModuleFileName,
									   OUT PHANDLE ModuleHandle);    

typedef VOID (WINAPI *fRtlInitUnicodeString)(PUNICODE_STRING DestinationString,
											 PCWSTR SourceString);   

typedef VOID (WINAPI *fRtlInitString)(PANSI_STRING DestinationString,
									  PCSTR SourceString);   

typedef NTSTATUS (WINAPI *fLdrGetProcedureAddress)(IN PVOID DllHandle,
												   IN PANSI_STRING ProcedureName OPTIONAL,
												   IN ULONG ProcedureNumber OPTIONAL,
												   OUT PVOID *ProcedureAddress);

typedef void (WINAPI *fDllExportTest)(const char*); 

HMODULE TestLdrLoadDll()
{
	HMODULE	hNtdll = GetModuleHandleA("ntdll.dll");
	fLdrLoadDll	_LdrLoadDll = (fLdrLoadDll)GetProcAddress (hNtdll,"LdrLoadDll");  
	fRtlInitUnicodeString _RtlInitUnicodeString = (fRtlInitUnicodeString)GetProcAddress (hNtdll,"RtlInitUnicodeString");  
	fRtlInitString _RtlInitString = (fRtlInitString)GetProcAddress (hNtdll,"RtlInitString");  

	int StrLen = lstrlenA(lpFileName);    
	BSTR WideStr = SysAllocStringLen(NULL, StrLen);    
	MultiByteToWideChar(CP_ACP, 0, lpFileName, StrLen, WideStr, StrLen);    

	UNICODE_STRING usDllName;    
	_RtlInitUnicodeString(&usDllName, WideStr);    
	SysFreeString(WideStr);    

	HANDLE DllHandle;    
	_LdrLoadDll(0, 0, &usDllName, &DllHandle);    

	fLdrGetProcedureAddress	_LdrGetProcedureAddress = (fLdrGetProcedureAddress)GetProcAddress (hNtdll,"LdrGetProcedureAddress");  
	ANSI_STRING asDllFuncName; 
	_RtlInitString(&asDllFuncName, "DllExportTest");    
	LPVOID lpTmp = 0;
	_LdrGetProcedureAddress(DllHandle, &asDllFuncName, NULL, &lpTmp);
	fDllExportTest _DllExportTest = (fDllExportTest)lpTmp;
	_DllExportTest("call dll");
	return (HMODULE)DllHandle;    
}

#include "../Detour/include/detours.h"
#pragma comment(lib,"../Detour/lib/x64/detours.lib")

bool g_b_hooked_msgboxa = false;

static int (WINAPI* OLD_MessageBoxW)(HWND hWnd,LPCWSTR lpText,LPCWSTR lpCaption,UINT uType) = MessageBoxW;
int WINAPI NEW_MessageBoxW(HWND hWnd,LPCWSTR lpText,LPCWSTR lpCaption,UINT uType)
{
	int ret = OLD_MessageBoxW(hWnd,L"����������޸�",L"[����]",uType);
	return ret;
}

void TestHook64()
{
	if (!g_b_hooked_msgboxa)
	{
		DetourRestoreAfterWith();
		DetourTransactionBegin();
		DetourUpdateThread(GetCurrentThread());

		//�������������ε���DetourAttach������HOOK�������
		DetourAttach(&(PVOID&)OLD_MessageBoxW,NEW_MessageBoxW);

		DetourTransactionCommit();	
	}
	else
	{
		DetourTransactionBegin();
		DetourUpdateThread(GetCurrentThread());

		//�������������ε���DetourDetach,���������������HOOK
		DetourDetach(&(PVOID&)OLD_MessageBoxW,NEW_MessageBoxW);

		DetourTransactionCommit();
	}
	MessageBoxW(NULL, NULL, NULL, NULL);
	g_b_hooked_msgboxa = !g_b_hooked_msgboxa;
}

void TestCreateProcess()
{
	PROCESS_INFORMATION info;
	STARTUPINFO si;
	memset(&si,0,sizeof(si));
	si.cb=sizeof(si);
	si.wShowWindow =SW_SHOW;
	si.dwFlags=STARTF_USESHOWWINDOW;
	WCHAR path[]=L"cmd";
	CreateProcess(NULL,path,NULL,NULL,0,CREATE_NEW_CONSOLE,NULL,NULL,&si,&info);
}

// �����ڡ������Ϣ��������
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDOK:
		case IDCANCEL:
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		case IDB_NEWPROCESS:
			TestCreateProcess();
			break;
		default:
			{}
		}
	}
	return (INT_PTR)FALSE;
}
