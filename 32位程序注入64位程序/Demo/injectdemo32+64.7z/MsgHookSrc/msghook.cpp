#define WIN32_LEAN_AND_MEAN             // �� Windows ͷ���ų�����ʹ�õ�����
// Windows ͷ�ļ�:
#include <windows.h>
#include <tchar.h>

HMODULE g_hModule = NULL;

typedef struct stHookInfo
{
	HHOOK hGetMsgHook;
	HHOOK hCallWndProcHook;
	DWORD dwThreadId;

	stHookInfo():hGetMsgHook(NULL), hCallWndProcHook(NULL), dwThreadId(0)
	{};
}HookInfo, *PHookInfo;

HookInfo g_hookInfo;

BOOL APIENTRY DllMain( HMODULE hModule,
					  DWORD  ul_reason_for_call,
					  LPVOID lpReserved
					  )
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		g_hModule = hModule;
		break;
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
		break;
	case DLL_PROCESS_DETACH:
		break;
	}
	return TRUE;
}

BOOL FilterMsg(UINT uMsg)
{
	switch (uMsg)
	{
	case WM_SIZE:
	case WM_SIZING:
	case WM_WINDOWPOSCHANGED:
	case WM_WINDOWPOSCHANGING:
	case WM_DESTROY:
	case WM_SHOWWINDOW:
		return TRUE;
	default:
		return FALSE;
	}
}

wchar_t* szInject_Class = L"#32770";
wchar_t* szInject_Name = L"AboutInject";

BOOL WINAPI HookProc(HWND hwnd,UINT uiMessage, WPARAM wParam,LPARAM lParam)
{
	if (FilterMsg(uiMessage))
	{
		HWND _hWnd = FindWindow(szInject_Class, szInject_Name);
		if (_hWnd)
		{
			// 			TCHAR sz[MAX_PATH] = {0};
			// 			wsprintf(sz, L"find window 0x%08X", _hWnd);
			LPARAM _lParam = wParam << 16 | uiMessage;
			PostMessage(_hWnd, WM_USER+100, (WPARAM)hwnd, _lParam);
			return TRUE;
		}
	}
	return FALSE;
}


LRESULT CALLBACK DllSpyGetMsgProc(INT hc,WPARAM wParam,LPARAM lParam)
{
	PMSG pmsg;
	pmsg = (PMSG)lParam;
	if (hc >= 0 && pmsg && pmsg->hwnd)
	{
		/*return*/ HookProc(pmsg->hwnd, pmsg->message, pmsg->wParam, pmsg->lParam);
	}
	return CallNextHookEx(NULL, hc, wParam, lParam);
}

LRESULT CALLBACK DllSpyCallWndProc(INT hc,WPARAM wParam,LPARAM lParam)
{
	PCWPSTRUCT pcwps;
	pcwps = (PCWPSTRUCT)lParam;
	if (hc >= 0 && pcwps && pcwps->hwnd)
	{
		/*return*/ HookProc(pcwps->hwnd, pcwps->message, pcwps->wParam, pcwps->lParam);
	}
	return CallNextHookEx(NULL, hc, wParam, lParam);
}

BOOL WINAPI SetMsgHook(DWORD dwThreadId)
{
	if (g_hookInfo.hGetMsgHook != NULL)
		return FALSE;

	g_hookInfo.hGetMsgHook = SetWindowsHookEx(WH_GETMESSAGE, DllSpyGetMsgProc, g_hModule, dwThreadId);
	if (!g_hookInfo.hGetMsgHook)
	{
		return FALSE;
	}

	g_hookInfo.hCallWndProcHook = SetWindowsHookEx(WH_CALLWNDPROC, DllSpyCallWndProc, g_hModule, dwThreadId);
	if (!g_hookInfo.hCallWndProcHook)
	{
		UnhookWindowsHookEx(g_hookInfo.hGetMsgHook);
		return FALSE;
	}
	return TRUE;
}


BOOL WINAPI UnsetMsgHook()
{	
	if (g_hookInfo.hGetMsgHook != NULL)
	{	
		UnhookWindowsHookEx(g_hookInfo.hGetMsgHook);
		g_hookInfo.hGetMsgHook = NULL;
	}
	if (g_hookInfo.hCallWndProcHook != NULL)
	{	
		UnhookWindowsHookEx(g_hookInfo.hCallWndProcHook);
		g_hookInfo.hCallWndProcHook = NULL;
	}
	return TRUE;
}

#include <stdlib.h>
#include <process.h>

// ����setwindowshook�ĺ���һ��Ҫȷ�����̴߳�����Ϣ���С���Ϊ�ص���post���˵��������ڵ��̣߳����뱣֤���ڡ�
unsigned __stdcall MsgHookThread(void *pVoid)
{
	char* szParam = (char*)pVoid;
	DWORD dwThreadId = atoi(szParam);
	if (dwThreadId == 0)
		return 1;

	// ȷ��������Ϣѭ��
	MSG msg;
	::PeekMessage(&msg, NULL, WM_USER, WM_USER, PM_NOREMOVE);

	if (!SetMsgHook(dwThreadId))
		return 2;

	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg); 
		DispatchMessage(&msg);
	}

	UnsetMsgHook();
	return 0;
}

HANDLE g_hMsgHookThread = NULL;
unsigned int g_dwMsgHookThreadId = 0;

extern "C" __declspec(dllexport) void /*WINAPI*/ SetMsgHookWrapper(const char* szParam)
{
	if (g_hMsgHookThread)
	{
		return;
	}
	g_hMsgHookThread = (HANDLE)_beginthreadex(NULL, 0, MsgHookThread, (LPVOID)szParam, 0, &g_dwMsgHookThreadId);
}

extern "C" __declspec(dllexport) void /*WINAPI*/ UnsetMsgHookWrapper(const char* szParam)
{
	PostThreadMessage(g_dwMsgHookThreadId, WM_QUIT, 0, 0);
	if (WaitForSingleObject(g_hMsgHookThread, 5*1000) != WAIT_OBJECT_0)
	{
		TerminateThread(g_hMsgHookThread, 0);
	}
	CloseHandle(g_hMsgHookThread);
	g_hMsgHookThread = NULL;
}

