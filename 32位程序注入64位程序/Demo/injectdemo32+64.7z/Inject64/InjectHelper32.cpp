#include "stdafx.h"
#include "Helper.h"
#include "InjectHelper32.h"


#define FillInString(addr, str)	\
	addr =  targetAddress + currentIdx;	\
	dwTmp = (DWORD)strlen(str) + 1;	\
	memcpy(currentAddress + currentIdx, str, dwTmp);	\
	currentIdx += dwTmp;

/* This is the way the following assembly code would look like in C/C++

// Load the injected DLL into this process
HMODULE h = GetModuleHandleA("xxx.dll");
if(h)
{
FARPROC p = GetProcAddress(h, "xxx");
if (p)
{
__asm call p(xxx)
}
}
ExitThread(0);
*/
unsigned char injectCode32_Head_Silent[] = {
	0x68, 0x00, 0x00, 0x00, 0x00,		// 0	PUSH {injectDllNameAddr}	:"inject.dll"
	0xB8, 0x00, 0x00, 0x00, 0x00,		// 5	MOV EAX, {FARPROC_LoadLibraryA}
	0xFF, 0xD0,							// 10	CALL EAX					:Call LoadLibraryA
	0x83, 0xF8,	0x00,					// 12	CMP EAX, 0
	0x74, 0x1E,							// 15	JZ EIP + 0x1E : skip over nRetor code
	0xA3, 0x00, 0x00, 0x00, 0x00,		// 17	MOV [injectDllAddr], EAX	:����mutehook.dll�ĵ�ַ
	0x68, 0x00, 0x00, 0x00, 0x00,		// 22	PUSH {injectFuncNameAddr}	:inject.dll�ĵ�������
	0x50,								// 27	Push EAX					:
	0xB8, 0x00, 0x00, 0x00, 0x00,		// 28	MOV EAX, {FARPROC_GetProcAddress}
	0xFF, 0xD0,							// 33	CALL EAX					:Call GetProcAddress
	0x83, 0xF8,	0x00,					// 35	CMP EAX, 0
	0x74, 0x07,							// 38	JZ EIP+ 0x07 : go to exit
	0x68, 0x00, 0x00, 0x00, 0x00,		// 40	PUSH [injectParamAddr]		:���������Ĳ���
	0xFF, 0xD0,							// 45	CALL EAX					:Call ExitThread���ߵ�������
};

unsigned char injectCode32_Tail_FreeLibraryAndET[] = {
	0x6A, 0x00,								// 0	Push 0
	0xFF, 0x35, 0x00, 0x00, 0x00, 0x00,		// 2	PUSH [injectDllAddr]
	0xB8, 0x00, 0x00, 0x00, 0x00,			// 8	MOV EAX, {FARPROC_FreeLibraryAndExitThread}
	0xFF, 0xD0,								// 13	CALL EAX				:Call FreeLibraryAndExitThread
};

unsigned char injectCode32_Tail_ExitThread[] = {
	0x6A, 0x00,								// 0	PUSH 0						
	0xB8, 0x00, 0x00, 0x00, 0x00,			// 2	MOV EAX, [exitthread]
	0xFF, 0xD0,								// 12	CALL EAX				:Call ExitThread
};

extern int g_lpvoid_loadlibrary;
extern int g_lpvoid_getprocaddress;
extern int g_lpvoid_exitthread;
extern int g_lpvoid_freelibraryandexitthread;

InjectResult Inject32Silent(DWORD dwPid, const char* dllname, const char* funcname, const char* param, bool bLoadDll, bool bUnloadDll)
{
	InjectResult nRet = OK;
	LPVOID targetWorkspace	= NULL;
	LPBYTE currentAddress	= NULL;
	HANDLE hProcess = NULL;
	HANDLE hThread = NULL;
	
	do 
	{
		// Step1. OpenProcess
		hProcess = OpenProcess(
			PROCESS_QUERY_INFORMATION |   // Required by Alpha
			PROCESS_CREATE_THREAD     |   // For CreateRemoteThread
			PROCESS_VM_OPERATION      |   // For VirtualAllocEx/VirtualFreeEx
			PROCESS_VM_WRITE,             // For WriteProcessMemory
			FALSE, dwPid);

		if (NULL == hProcess)
		{
			nRet = Error_OpenProcess;
			break;
		}

		// Step2. Create the currentAddress
		currentAddress = (LPBYTE)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, 1024);
		if (NULL == currentAddress)
		{
			nRet = Error_HeapAlloc;
			break;
		}

		// Step3. Allocate space for the codecave in the process
		targetWorkspace = VirtualAllocEx(hProcess, 0, 1024, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
		if (NULL == targetWorkspace)
		{
			nRet = Error_VirtualAllocEx;
			break;
		}

		DWORD targetAddress = PtrToUlong(targetWorkspace);

		// Step4. Prepare machine codes to run in target process

		// 4.1. ��ȡһЩ�����ĵ�ַ
// 		HMODULE kernel32	= LoadLibraryA("kernel32.dll");
// 		FARPROC loadlibrary		= GetProcAddress(kernel32,	bLoadDll ? "LoadLibraryA" : "GetModuleHandleA");
// 		FARPROC getprocaddress	= GetProcAddress(kernel32,	"GetProcAddress");
// 		FARPROC exitthread		= GetProcAddress(kernel32,	"ExitThread");
// 		FARPROC freelibraryandexitthread = GetProcAddress(kernel32,	"FreeLibraryAndExitThread");
// 		loadlibrary		= (FARPROC)0x76d448c7;
// 		getprocaddress	= (FARPROC)0x76d41222;
// 		exitthread		= (FARPROC)0x775523c9;
// 		freelibraryandexitthread = (FARPROC)0x76d5d5ca;

		// ��Щ��Ҫʵʱ��ȡ
		FARPROC loadlibrary		= (FARPROC)g_lpvoid_loadlibrary;
		FARPROC getprocaddress	= (FARPROC)g_lpvoid_getprocaddress;
		FARPROC exitthread		= (FARPROC)g_lpvoid_exitthread;
		FARPROC freelibraryandexitthread = (FARPROC)g_lpvoid_freelibraryandexitthread;

		// ����
		DWORD currentIdx	= 0;
		DWORD dwTmp = 0;

		// 4.2. ���һ��ָ��ռ�
		size_t sizePtr = sizeof(int*);
		const size_t addressCount = 1;
		for (size_t i = 0 ; i < addressCount * sizePtr; i++)
		{
			currentAddress[i] = 0x00;
		}
		currentIdx += addressCount * sizePtr;		// �ƽ�����
		DWORD injectDllAddr = targetAddress + 0;	// ��Ŵ�ע���dll�ļ��ص�ַ

		// 4.3. ����ַ���
		char injectDllName[MAX_PATH + 1]	= {0};
		char injectFuncName[MAX_PATH + 1]	= {0};
		char injectParam[MAX_PATH*2 + 1]	= {0};
		_snprintf_s(injectDllName, MAX_PATH, MAX_PATH -1, "%s", dllname);
		_snprintf_s(injectFuncName, MAX_PATH, MAX_PATH -1, "%s", funcname);
		_snprintf_s(injectParam, MAX_PATH*2, MAX_PATH*2 -1, "%s", param);

		DWORD injectDllNameAddr		= 0;
		DWORD injectFuncNameAddr	= 0;
		DWORD injectParamAddr		= 0;
		FillInString(injectDllNameAddr, injectDllName)
		FillInString(injectFuncNameAddr, injectFuncName)
		FillInString(injectParamAddr, injectParam)


		// 4.4. ���һЩint3���ָ��ַ������ʹ�����
		const size_t int3_count = 3;
		for (size_t i = 0 ; i < int3_count; i++)
		{
			currentAddress[currentIdx++] = 0xCC;
		}

		// 4.5 ���������Ĵ��뿪ʼλ��
		DWORD targetExcuteCodeAddress =  targetAddress + currentIdx;

		// 4.6. ����������
		memcpy(injectCode32_Head_Silent + 1, &injectDllNameAddr, 4);
		memcpy(injectCode32_Head_Silent + 6, &loadlibrary, 4);
		memcpy(injectCode32_Head_Silent + 18, &injectDllAddr, 4);
		memcpy(injectCode32_Head_Silent + 23, &injectFuncNameAddr, 4);
		memcpy(injectCode32_Head_Silent + 29, &getprocaddress, 4);
		memcpy(injectCode32_Head_Silent + 41, &injectParamAddr, 4);
		memcpy(currentAddress + currentIdx, injectCode32_Head_Silent ,sizeof(injectCode32_Head_Silent));
		currentIdx += sizeof(injectCode32_Head_Silent);

		if (bUnloadDll)
		{
			memcpy(injectCode32_Tail_FreeLibraryAndET + 4, &injectDllAddr, 4);
			memcpy(injectCode32_Tail_FreeLibraryAndET + 9, &freelibraryandexitthread, 4);
			memcpy(currentAddress + currentIdx, injectCode32_Tail_FreeLibraryAndET ,sizeof(injectCode32_Tail_FreeLibraryAndET));
			currentIdx += sizeof(injectCode32_Tail_FreeLibraryAndET);
		}
		else
		{
			memcpy(injectCode32_Tail_ExitThread + 3, &exitthread, 4);
			memcpy(currentAddress + currentIdx, injectCode32_Tail_ExitThread ,sizeof(injectCode32_Tail_ExitThread));
			currentIdx += sizeof(injectCode32_Tail_ExitThread);
		}


		// Step5. Change page protection so we can write executable code
		DWORD oldProtect	= 0;	
		VirtualProtectEx(hProcess, targetWorkspace, currentIdx, PAGE_EXECUTE_READWRITE, &oldProtect);

		// Step6. Write out the patch
		size_t bytesRet		= 0;
		if (!WriteProcessMemory(hProcess, targetWorkspace, currentAddress, currentIdx, &bytesRet))
		{
			nRet = Error_WriteProcessMemory;
			break;
		}

		// Step7. Restore page protection
		VirtualProtectEx(hProcess, targetWorkspace, currentIdx, oldProtect, &oldProtect);

		// Step8. Make sure our changes are written right away
		FlushInstructionCache(hProcess, targetWorkspace, currentIdx);

		// Step9. Execute the thread now and wait for it to exit, note we execute where the code starts, and not the codecave start
		// (since we wrote strings at the start of the codecave) -- NOTE: void* used for VC6 compatibility instead of UlongToPtr
		hThread = CreateRemoteThread(hProcess, NULL, 0, (LPTHREAD_START_ROUTINE)((void*)targetExcuteCodeAddress), 0, 0, NULL);
		if (NULL == hThread)
		{
			nRet = Error_CreateRemoteThread;
			break;
		}
		WaitForSingleObject(hThread, INFINITE); 

	} while (0);

	// Step10. Cleanup
	if (hProcess)
	{
		CloseHandle(hProcess);
	}

	if (hThread)
	{
		CloseHandle(hThread);
	}

	// Free the memory in the process that we allocated
	if (targetWorkspace)
	{
		VirtualFreeEx(hProcess, targetWorkspace, 0, MEM_RELEASE);
	}

	// Free the currentAddress memory
	if (currentAddress)
	{
		HeapFree(GetProcessHeap(), 0, currentAddress);
	}

	return nRet;
}