// Inject64.cpp : ����Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <shlobj.h>
#include <ShellAPI.h>
#include <TlHelp32.h>
#include "InjectHelper.h"
#include "Inject64.h"

int g_lpvoid_loadlibrary = NULL;
int g_lpvoid_getprocaddress = NULL;
int g_lpvoid_exitthread = NULL;
int g_lpvoid_freelibraryandexitthread = NULL;

extern "C"
{  
	int _stdcall Int_3();  
	int _stdcall MY_TEST();  
}  

LRESULT OnRecvUserMsg(UINT uMsg, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

int APIENTRY _tWinMain(HINSTANCE hInstance,
					   HINSTANCE hPrevInstance,
					   LPTSTR    lpCmdLine,
					   int       nCmdShow)
{
	DialogBox(hInstance, MAKEINTRESOURCE(IDD_ABOUTBOX), NULL, About);
	return 0;
}

DWORD GetPidInject(const wchar_t* szExe)
{
	HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	if (INVALID_HANDLE_VALUE == hSnapshot) 
	{
		return 0;
	}

	DWORD dwPid = 0;
	PROCESSENTRY32 pe = {sizeof(pe)};
	BOOL ret = Process32First(hSnapshot, &pe);
	for (; ret; ) 
	{
		if( 0 == _tcscmp(szExe, pe.szExeFile))
		{
			dwPid = pe.th32ProcessID;
			break;
		}
		ret = Process32Next(hSnapshot, &pe);
	}
	CloseHandle(hSnapshot);
	return dwPid;
}


bool CheckWin32FunctionAddress()
{
	if (!g_lpvoid_exitthread ||
		!g_lpvoid_freelibraryandexitthread ||
		!g_lpvoid_getprocaddress ||
		!g_lpvoid_loadlibrary)
	{
		MessageBox(NULL, L"��Ҫ��紫��wow64��loadlibrary,getprocaddress�Ⱥ����ĵ�ַ", L"����", NULL);
		return false;
	}
	return true;
}

void TestInject32_Mute()
{
	if (!CheckWin32FunctionAddress())
		return;

	InjectHelper(GetPidInject(L"Win32VS2008.exe"), "MuteHook32.dll", "MuteHook.dll", "SetCreateProcessHookWrapper", "", true, false);
}

void TestUnInject32_Mute()
{
	if (!CheckWin32FunctionAddress())
		return;

	InjectHelper(GetPidInject(L"Win32VS2008.exe"), "MuteHook32.dll", "MuteHook.dll", "UnsetCreateProcessHookWrapper", "", false, true);
}

void TestInject64_Mute()
{
	InjectHelper(GetPidInject(L"Win64VS2008.exe"), "MuteHook32.dll", "MuteHook.dll", "SetCreateProcessHookWrapper", "", true, false);
}


void TestUnInject64_Mute()
{
	InjectHelper(GetPidInject(L"Win64VS2008.exe"), "MuteHook32.dll", "MuteHook.dll", "UnsetCreateProcessHookWrapper", "", false, true);
}

HWND g_hWndListening = NULL;

void TestInject32_Msg()
{
	if (!CheckWin32FunctionAddress())
		return;

	HWND hWnd = FindWindow(L"#32770", L"Win32VS2008");
	DWORD dwThreadId = GetWindowThreadProcessId(hWnd, NULL);
	char szParam[200];
	sprintf(szParam, "%d", dwThreadId);
	g_hWndListening = hWnd;

	InjectHelper(GetPidInject(L"Win32VS2008.exe"), "MsgHook32.dll", "MsgHook.dll", "SetMsgHookWrapper", szParam, true, false);
}

void TestUnInject32_Msg()
{
	if (!CheckWin32FunctionAddress())
		return;

	InjectHelper(GetPidInject(L"Win32VS2008.exe"), "MsgHook32.dll", "MsgHook.dll", "UnsetMsgHookWrapper", "", false, true);
}

void TestInject64_Msg()
{
	HWND hWnd = FindWindow(L"#32770", L"Win64VS2008");
	DWORD dwThreadId = GetWindowThreadProcessId(hWnd, NULL);
	char szParam[200];
	sprintf(szParam, "%d", dwThreadId);
	g_hWndListening = hWnd;

	InjectHelper(GetPidInject(L"Win64VS2008.exe"), "MsgHook32.dll", "MsgHook.dll", "SetMsgHookWrapper", szParam, true, false);
}

void TestUnInject64_Msg()
{
	InjectHelper(GetPidInject(L"Win64VS2008.exe"), "MsgHook32.dll", "MsgHook.dll", "UnsetMsgHookWrapper", "", false, true);
}


// �����ڡ������Ϣ��������
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDOK:
		case IDCANCEL:
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		case IDB_INJECT64_MSG:
			TestInject64_Msg();
			break;
		case IDB_UNINJECT64_MSG:
			TestUnInject64_Msg();
			break;
		case IDB_INJECT64_MUTE:
			TestInject64_Mute();
			break;
		case IDB_UNINJECT64_MUTE:
			TestUnInject64_Mute();
			break;
		case IDB_INJECT32_MSG:
			TestInject32_Msg();
			break;
		case IDB_UNINJECT32_MSG:
			TestUnInject32_Msg();
			break;
		case IDB_INJECT32_MUTE:
			TestInject32_Mute();
			break;
		case IDB_UNINJECT32_MUTE:
			TestUnInject32_Mute();
			break;
		default:
			{}
		}
	case WM_USER+100:
		OnRecvUserMsg(message, wParam, lParam);
	}
	return (INT_PTR)FALSE;
}

LRESULT OnRecvUserMsg(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if ((HWND)wParam != g_hWndListening)
		return 0;

	WPARAM _wParam = HIWORD(lParam);
	UINT _uMsg = LOWORD(lParam);
	switch (_uMsg)
	{
	case WM_DESTROY:
		OutputDebugString(L"recv WM_DESTROY\n");
		break;
	case WM_SIZE:
		OutputDebugString(L"recv WM_SIZE\n");
		break;
	case WM_SIZING:
		OutputDebugString(L"recv WM_SIZING\n");
		break;
	case WM_WINDOWPOSCHANGED:
		OutputDebugString(L"recv WM_WINDOWPOSCHANGED\n");
		break;
	case WM_WINDOWPOSCHANGING:
		OutputDebugString(L"recv WM_WINDOWPOSCHANGING\n");
		break;
	case WM_SHOWWINDOW:
		OutputDebugString(L"recv WM_SHOWWINDOW\n");
		break;
	default:
		{}
	}
	return 0;
}

