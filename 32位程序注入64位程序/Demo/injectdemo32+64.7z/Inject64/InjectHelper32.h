#pragma once
#include "Helper.h"

InjectResult Inject32Silent(DWORD dwPid, const char* dllname, const char* funcname, const char* param, bool bLoadDll, bool bUnloadDll);