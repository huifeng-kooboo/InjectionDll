#include "stdafx.h"
#include "Helper.h"
#include "InjectHelper64.h"


#define FillInString(addr, str)	\
	addr =  targetAddress + currentIdx;	\
	dwTmp = (DWORD)strlen(str) + 1;	\
	memcpy(currentAddress + currentIdx, str, dwTmp);	\
	currentIdx += dwTmp;

/* This is the way the following assembly code would look like in C/C++

// Load the injected DLL into this process
HMODULE h = GetModuleHandleA("xxx.dll");
if(h)
{
FARPROC p = GetProcAddress(h, "xxx");
if (p)
{
__asm call p(xxx)
}
}
ExitThread(0);
*/
unsigned char injectCode_Head_Silent[] = {

	0x48, 0x89, 0x4c, 0x24, 0x08,                               // 0	mov       qword ptr [rsp+8],rcx 
	0x57,                                                       // 5	push      rdi
	0x48, 0x83, 0xec, 0x20,                                     // 6	sub       rsp,20h
	0x48, 0x8b, 0xfc,                                           // 10	mov       rdi,rsp
	0xb9, 0x08, 0x00, 0x00, 0x00,                               // 13	mov       ecx,8
	0xb8, 0xcc, 0xcc, 0xcc, 0xcc,                               // 18	mov       eac,0CCCCCCCCh
	0xf3, 0xab,                                                 // 23	rep stos  dword ptr [rdi]
	0x48, 0x8b, 0x4c, 0x24, 0x30,                               // 25	mov       rcx,qword ptr [__formal]

	// ����dll
	0x48, 0xb9, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 30	mov       rcx,0	: inject.dll
	0x48, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 40	mov       rax,0 : LoadLibraryA
	0xff, 0xd0,                                                 // 50	call      rax	: Call LoadLibraryA

	0x48, 0xba, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 52	mov       rdx,0	//PANSI_STRING Name
	0x48, 0x89, 0x02,                                           // 62	mov       dword ptr [rdx],rax

	// ��ȡdll�к�����ַ
	0x48, 0xba, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 52	mov       rdx,0	: inject.dll�ĵ�������
	0x48, 0x8b, 0xc8,											// 62	mov       rcx,rax  
	0x48, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 65	mov       rax,0 : GetProcAddress
	0xff, 0xd0,                                                 // 75	call      rax	: Call GetProcAddress

	// ����dll�к���
	0x48, 0xb9, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 77	mov       rcx,0 : ����
	0xff, 0xd0,                                                 // 87	call      rax	Call Dll:Fun
};

unsigned char injectCode_Tail_FreeLibraryAndET[] = {
	0x48, 0xba, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 0	mov       rdx,0
	0x48, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 10	mov       rax,	{//PVOID*  DllBaseAddr opt} 
	0x48, 0x8b, 0x00,											// 20	rax,qword ptr [rax]  
	0x48, 0x8b, 0xc8,											// 23	mov       rcx,rax  
	0x48, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 26	mov       rax,0 : FreeLibraryAndExitThread
	0xff, 0xd0,                                                 // 36	call      rax	: Call FreeLibraryAndExitThread
};

unsigned char injectCode_Tail_ExitThread[] = {
	0x48, 0xb9, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 0	mov       rcx,0
	0x48, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 10	mov       rax,0 : exitthread
	0xff, 0xd0,                                                 // 20	call      rax	: Call exitthread
};

InjectResult Inject64Silent(DWORD dwPid, const char* dllname, const char* funcname, const char* param, bool bLoadDll, bool bUnloadDll)
{
	InjectResult nRet = OK;
	LPVOID targetWorkspace	= NULL;
	LPBYTE currentAddress	= NULL;
	HANDLE hProcess = NULL;
	HANDLE hThread = NULL;
	
	do 
	{
		// Step1. OpenProcess
		hProcess = OpenProcess(
			PROCESS_QUERY_INFORMATION |   // Required by Alpha
			PROCESS_CREATE_THREAD     |   // For CreateRemoteThread
			PROCESS_VM_OPERATION      |   // For VirtualAllocEx/VirtualFreeEx
			PROCESS_VM_WRITE,             // For WriteProcessMemory
			FALSE, dwPid);

		if (NULL == hProcess)
		{
			nRet = Error_OpenProcess;
			break;
		}

		// Step2. Create the currentAddress
		currentAddress = (LPBYTE)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, 1024);
		if (NULL == currentAddress)
		{
			nRet = Error_HeapAlloc;
			break;
		}

		// Step3. Allocate space for the codecave in the process
		targetWorkspace = VirtualAllocEx(hProcess, 0, 1024, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
		if (NULL == targetWorkspace)
		{
			nRet = Error_VirtualAllocEx;
			break;
		}

		__int64 targetAddress = PtrToUlong(targetWorkspace);

		// Step4. Prepare machine codes to run in target process

		// 4.1. ��ȡһЩ�����ĵ�ַ
		HMODULE kernel32	= LoadLibraryA("kernel32.dll");
		FARPROC loadlibrary		= GetProcAddress(kernel32,	bLoadDll ? "LoadLibraryA" : "GetModuleHandleA");
		FARPROC getprocaddress	= GetProcAddress(kernel32,	"GetProcAddress");
		FARPROC exitthread		= GetProcAddress(kernel32,	"ExitThread");
		FARPROC freelibraryandexitthread = GetProcAddress(kernel32,	"FreeLibraryAndExitThread");

		// ����
		DWORD currentIdx	= 0;
		DWORD dwTmp = 0;

		// 4.2. ���һ��ָ��ռ�
		size_t sizePtr = sizeof(int*);
		const size_t addressCount = 1;
		for (size_t i = 0 ; i < addressCount * sizePtr; i++)
		{
			currentAddress[i] = 0x00;
		}
		currentIdx += addressCount * sizePtr;		// �ƽ�����
		__int64 injectDllAddr = targetAddress + 0;	// ��Ŵ�ע���dll�ļ��ص�ַ

		// 4.3. ����ַ���
		char injectDllName[MAX_PATH + 1]	= {0};
		char injectFuncName[MAX_PATH + 1]	= {0};
		char injectParam[MAX_PATH*2 + 1]	= {0};
		_snprintf_s(injectDllName, MAX_PATH, MAX_PATH -1, "%s", dllname);
		_snprintf_s(injectFuncName, MAX_PATH, MAX_PATH -1, "%s", funcname);
		_snprintf_s(injectParam, MAX_PATH*2, MAX_PATH*2 -1, "%s", param);

		__int64 injectDllNameAddr		= 0;
		__int64 injectFuncNameAddr	= 0;
		__int64 injectParamAddr		= 0;
		FillInString(injectDllNameAddr, injectDllName)
		FillInString(injectFuncNameAddr, injectFuncName)
		FillInString(injectParamAddr, injectParam)

		// 4.4. ���һЩint3���ָ��ַ������ʹ�����
		const size_t int3_count = 3;
		for (size_t i = 0 ; i < int3_count; i++)
		{
			currentAddress[currentIdx++] = 0xCC;
		}

		// 4.5 ���������Ĵ��뿪ʼλ��
		__int64 targetExcuteCodeAddress =  targetAddress + currentIdx;

		// 4.6. ����������
		memcpy(injectCode_Head_Silent + 32, &injectDllNameAddr, 8);
		memcpy(injectCode_Head_Silent + 42, &loadlibrary, 8);
		memcpy(injectCode_Head_Silent + 54, &injectDllAddr, 8);
		memcpy(injectCode_Head_Silent + 54+13, &injectFuncNameAddr, 8);
		memcpy(injectCode_Head_Silent + 67+13, &getprocaddress, 8);
		memcpy(injectCode_Head_Silent + 79+13, &injectParamAddr, 8);
		memcpy(currentAddress + currentIdx, injectCode_Head_Silent ,sizeof(injectCode_Head_Silent));
		currentIdx += sizeof(injectCode_Head_Silent);

		if (bUnloadDll)
		{
			memcpy(injectCode_Tail_FreeLibraryAndET + 12, &injectDllAddr, 8);
			memcpy(injectCode_Tail_FreeLibraryAndET + 28, &freelibraryandexitthread, 8);
			memcpy(currentAddress + currentIdx, injectCode_Tail_FreeLibraryAndET ,sizeof(injectCode_Tail_FreeLibraryAndET));
			currentIdx += sizeof(injectCode_Tail_FreeLibraryAndET);
		}
		else
		{
			memcpy(injectCode_Tail_ExitThread + 12, &exitthread, 8);
			memcpy(currentAddress + currentIdx, injectCode_Tail_ExitThread ,sizeof(injectCode_Tail_ExitThread));
			currentIdx += sizeof(injectCode_Tail_ExitThread);
		}


		// Step5. Change page protection so we can write executable code
		DWORD oldProtect	= 0;	
		VirtualProtectEx(hProcess, targetWorkspace, currentIdx, PAGE_EXECUTE_READWRITE, &oldProtect);

		// Step6. Write out the patch
		size_t bytesRet		= 0;
		if (!WriteProcessMemory(hProcess, targetWorkspace, currentAddress, currentIdx, &bytesRet))
		{
			nRet = Error_WriteProcessMemory;
			break;
		}

		// Step7. Restore page protection
		VirtualProtectEx(hProcess, targetWorkspace, currentIdx, oldProtect, &oldProtect);

		// Step8. Make sure our changes are written right away
		FlushInstructionCache(hProcess, targetWorkspace, currentIdx);

		// Step9. Execute the thread now and wait for it to exit, note we execute where the code starts, and not the codecave start
		// (since we wrote strings at the start of the codecave) -- NOTE: void* used for VC6 compatibility instead of UlongToPtr
		hThread = CreateRemoteThread(hProcess, NULL, 0, (LPTHREAD_START_ROUTINE)((void*)targetExcuteCodeAddress), 0, 0, NULL);
		if (NULL == hThread)
		{
			nRet = Error_CreateRemoteThread;
			break;
		}
		WaitForSingleObject(hThread, INFINITE); 

	} while (0);

	// Step10. Cleanup
	if (hProcess)
	{
		CloseHandle(hProcess);
	}

	if (hThread)
	{
		CloseHandle(hThread);
	}

	// Free the memory in the process that we allocated
	if (targetWorkspace)
	{
		VirtualFreeEx(hProcess, targetWorkspace, 0, MEM_RELEASE);
	}

	// Free the currentAddress memory
	if (currentAddress)
	{
		HeapFree(GetProcessHeap(), 0, currentAddress);
	}

	return nRet;
}