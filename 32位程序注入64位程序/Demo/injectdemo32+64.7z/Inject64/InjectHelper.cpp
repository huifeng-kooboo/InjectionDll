#include "stdafx.h"
#include "Helper.h"
#include "InjectHelper32.h"
#include "InjectHelper64.h"

void InjectHelper(DWORD dwPid, 
				  const char* szDllname86, 
				  const char* szDllname64, 
				  const char* szFunName, 
				  const char* szParam, 
				  bool bLoadDll, bool 
				  bUnloadDll)
{
	InjectResult nRet = OK;
	if (Is64BitProcess(dwPid))
	{
		nRet = Inject64Silent(dwPid, szDllname64, szFunName, szParam, bLoadDll, bUnloadDll);
	}
	else
	{
// #ifdef _DEBUG
// 		nRet = Inject32WithErrorPrompt(dwPid, szDllname86, szFunName, szParam, bLoadDll, bUnloadDll);
// #else
		nRet = Inject32Silent(dwPid, szDllname86, szFunName, szParam, bLoadDll, bUnloadDll);
// #endif
	}

	if (nRet != OK)
	{
		FmtDebugOut(L"error occurs when inject dll. errcode:%d, errdes:%s", nRet, GetInjectErrorDesc(nRet));
	}
}
