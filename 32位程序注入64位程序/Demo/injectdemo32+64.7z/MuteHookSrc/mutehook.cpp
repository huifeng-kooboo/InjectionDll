// dllmain.cpp : ���� DLL Ӧ�ó������ڵ㡣
#include "stdafx.h"

#include "../Detour/include/detours.h"

#ifdef _WIN64
	#pragma comment(lib,"../Detour/lib/x64/detours.lib")
#else
	#pragma comment(lib,"../Detour/lib/x86/detours.lib")
#endif

long UnHook(void ** ppFun,PVOID pDetour)
{
	//       DetourRestoreAfterWith();
	DetourTransactionBegin();
	//Detour
	DetourUpdateThread(GetCurrentThread());
	DetourDetach(ppFun,pDetour);
	return DetourTransactionCommit();
}


long Hook(void ** ppOld,PVOID pNew)
{
	//       DetourRestoreAfterWith();
	DetourTransactionBegin();
	//Detour
	DetourUpdateThread(GetCurrentThread());
	DetourAttach(ppOld,pNew);
	return DetourTransactionCommit();
}

typedef BOOL (WINAPI *PCreateProcessInternalA)(HANDLE,
												  LPCSTR,
												  LPSTR,
												  LPSECURITY_ATTRIBUTES,
												  LPSECURITY_ATTRIBUTES,
												  BOOL,
												  DWORD,
												  LPVOID,
												  LPCSTR,
												  LPSTARTUPINFOW,
												  LPPROCESS_INFORMATION,
												  PHANDLE);

PCreateProcessInternalA pCreateProcessInternalA = NULL; 

BOOL WINAPI myCreateProcessInternalA(HANDLE hToken,
									 LPCSTR lpApplicationName,
									 LPSTR lpCommandLine,
									 LPSECURITY_ATTRIBUTES lpProcessAttributes,
									 LPSECURITY_ATTRIBUTES lpThreadAttributes,
									 BOOL bInheritHandles,
									 DWORD dwCreationFlags,
									 LPVOID lpEnvironment,
									 LPCSTR lpCurrentDirectory,
									 LPSTARTUPINFOW lpStartupInfo,
									 LPPROCESS_INFORMATION lpProcessInformation,
									 PHANDLE hNewToken)
{
	MessageBoxA(NULL, __FUNCTION__, __FUNCTION__, 0);
	return pCreateProcessInternalA(hToken, lpApplicationName, lpCommandLine, 
		lpProcessAttributes, lpThreadAttributes, bInheritHandles, 
		dwCreationFlags, lpEnvironment, lpCurrentDirectory, 
		lpStartupInfo,lpProcessInformation,hNewToken);
}

typedef BOOL (WINAPI *PCreateProcessInternalW)(HANDLE,
												  LPCWSTR,
												  LPWSTR,
												  LPSECURITY_ATTRIBUTES,
												  LPSECURITY_ATTRIBUTES,
												  BOOL,
												  DWORD,
												  LPVOID,
												  LPCWSTR,
												  LPSTARTUPINFOW,
												  LPPROCESS_INFORMATION,
												  PHANDLE);

PCreateProcessInternalW pCreateProcessInternalW = NULL; 

BOOL WINAPI myCreateProcessInternalW(HANDLE hToken,
									 LPCWSTR lpApplicationName,
									 LPWSTR lpCommandLine,
									 LPSECURITY_ATTRIBUTES lpProcessAttributes,
									 LPSECURITY_ATTRIBUTES lpThreadAttributes,
									 BOOL bInheritHandles,
									 DWORD dwCreationFlags,
									 LPVOID lpEnvironment,
									 LPCWSTR lpCurrentDirectory,
									 LPSTARTUPINFOW lpStartupInfo,
									 LPPROCESS_INFORMATION lpProcessInformation,
									 PHANDLE hNewToken)
{
	MessageBoxA(NULL, __FUNCTION__, __FUNCTION__, 0);
	return pCreateProcessInternalW(hToken, lpApplicationName, lpCommandLine, 
		lpProcessAttributes, lpThreadAttributes, bInheritHandles, 
		dwCreationFlags, lpEnvironment, lpCurrentDirectory, 
		lpStartupInfo,lpProcessInformation,hNewToken);
}


typedef BOOL (WINAPI *PCreateProcessAsUserA)(HANDLE,
											 LPCSTR,
											 LPSTR,
											 LPSECURITY_ATTRIBUTES,
											 LPSECURITY_ATTRIBUTES,
											 BOOL,
											 DWORD,
											 LPVOID,
											 LPCSTR,
											 LPSTARTUPINFOW,
											 LPPROCESS_INFORMATION);

PCreateProcessAsUserA pCreateProcessAsUserA = NULL; 

BOOL WINAPI myCreateProcessAsUserA(HANDLE hToken,
								   LPCSTR lpApplicationName,
								   LPSTR lpCommandLine,
								   LPSECURITY_ATTRIBUTES lpProcessAttributes,
								   LPSECURITY_ATTRIBUTES lpThreadAttributes,
								   BOOL bInheritHandles,
								   DWORD dwCreationFlags,
								   LPVOID lpEnvironment,
								   LPCSTR lpCurrentDirectory,
								   LPSTARTUPINFOW lpStartupInfo,
								   LPPROCESS_INFORMATION lpProcessInformation)
{
	MessageBoxA(NULL, __FUNCTION__, __FUNCTION__, 0);
	return pCreateProcessAsUserA(hToken, lpApplicationName, lpCommandLine, 
		lpProcessAttributes, lpThreadAttributes, bInheritHandles, 
		dwCreationFlags, lpEnvironment, lpCurrentDirectory, 
		lpStartupInfo,lpProcessInformation);
}

typedef BOOL (WINAPI *PCreateProcessAsUserW)(HANDLE,
											 LPCWSTR,
											 LPWSTR,
											 LPSECURITY_ATTRIBUTES,
											 LPSECURITY_ATTRIBUTES,
											 BOOL,
											 DWORD,
											 LPVOID,
											 LPCWSTR,
											 LPSTARTUPINFOW,
											 LPPROCESS_INFORMATION);

PCreateProcessAsUserW pCreateProcessAsUserW = NULL; 

BOOL WINAPI myCreateProcessAsUserW(HANDLE hToken,
								   LPCWSTR lpApplicationName,
								   LPWSTR lpCommandLine,
								   LPSECURITY_ATTRIBUTES lpProcessAttributes,
								   LPSECURITY_ATTRIBUTES lpThreadAttributes,
								   BOOL bInheritHandles,
								   DWORD dwCreationFlags,
								   LPVOID lpEnvironment,
								   LPCWSTR lpCurrentDirectory,
								   LPSTARTUPINFOW lpStartupInfo,
								   LPPROCESS_INFORMATION lpProcessInformation)
{
	MessageBoxA(NULL, __FUNCTION__, __FUNCTION__, 0);
	return pCreateProcessAsUserW(hToken, lpApplicationName, lpCommandLine, 
		lpProcessAttributes, lpThreadAttributes, bInheritHandles, 
		dwCreationFlags, lpEnvironment, lpCurrentDirectory, 
		lpStartupInfo,lpProcessInformation);
}

typedef BOOL (WINAPI *PCreateProcessA)(LPCTSTR lpApplicationName,
									   LPTSTR lpCommandLine,
									   LPSECURITY_ATTRIBUTES lpProcessAttributes,
									   LPSECURITY_ATTRIBUTES lpThreadAttributes,
									   BOOL bInheritHandles,
									   DWORD dwCreationFlags,
									   LPVOID lpEnvironment,
									   LPCTSTR lpCurrentDirectory,
									   LPSTARTUPINFO lpStartupInfo,
									   LPPROCESS_INFORMATION lpProcessInformation);

PCreateProcessA pCreateProcessA = NULL;

BOOL WINAPI myCreateProcessA(LPCTSTR lpApplicationName,
							 LPTSTR lpCommandLine,
							 LPSECURITY_ATTRIBUTES lpProcessAttributes,
							 LPSECURITY_ATTRIBUTES lpThreadAttributes,
							 BOOL bInheritHandles,
							 DWORD dwCreationFlags,
							 LPVOID lpEnvironment,
							 LPCTSTR lpCurrentDirectory,
							 LPSTARTUPINFO lpStartupInfo,
							 LPPROCESS_INFORMATION lpProcessInformation)
{
	MessageBoxA(NULL, __FUNCTION__, __FUNCTION__, 0);
	return pCreateProcessA(lpApplicationName,
		lpCommandLine,
		lpProcessAttributes,
		lpThreadAttributes,
		bInheritHandles,
		dwCreationFlags,
		lpEnvironment,
		lpCurrentDirectory,
		lpStartupInfo,
		lpProcessInformation);
}

typedef int (WINAPI *PCreateProcessW)(LPCWSTR lpApplicationName,
									  LPWSTR lpCommandLine,
									  LPSECURITY_ATTRIBUTES lpProcessAttributes, 
									  LPSECURITY_ATTRIBUTES lpThreadAttributes,
									  BOOL bInheritHandles,
									  DWORD dwCreationFlags,
									  LPVOID lpEnvironment,
									  LPCWSTR lpCurrentDirectory,
									  LPSTARTUPINFOW lpStartupInfo, 
									  LPPROCESS_INFORMATION lpProcessInformation);

PCreateProcessW pCreateProcessW = NULL;

int WINAPI myCreateProcessW(LPCWSTR lpApplicationName,
							LPWSTR lpCommandLine,
							LPSECURITY_ATTRIBUTES lpProcessAttributes, 
							LPSECURITY_ATTRIBUTES lpThreadAttributes,
							BOOL bInheritHandles,
							DWORD dwCreationFlags,
							LPVOID lpEnvironment,
							LPCWSTR lpCurrentDirectory,
							LPSTARTUPINFOW lpStartupInfo, 
							LPPROCESS_INFORMATION lpProcessInformation)
{
	MessageBoxA(NULL, __FUNCTION__, __FUNCTION__, 0);
	return pCreateProcessW(lpApplicationName,
		lpCommandLine,
		lpProcessAttributes,
		lpThreadAttributes,
		bInheritHandles,
		dwCreationFlags,
		lpEnvironment,
		lpCurrentDirectory,
		lpStartupInfo,
		lpProcessInformation);
}


bool g_b_hooked = false;

extern "C" __declspec(dllexport) void  SetCreateProcessHookWrapper(const char* szParam)
{
	if (g_b_hooked)
		return;

	g_b_hooked = true;
	{
		HMODULE hMod=GetModuleHandleW(L"Kernel32.dll");

		pCreateProcessInternalW = (PCreateProcessInternalW)GetProcAddress(hMod,"CreateProcessInternalW");
		Hook((LPVOID*)&pCreateProcessInternalW, myCreateProcessInternalW);

		pCreateProcessW = (PCreateProcessW)GetProcAddress(hMod,"CreateProcessW");
		Hook((LPVOID*)&pCreateProcessW, myCreateProcessW);

		pCreateProcessA = (PCreateProcessA)GetProcAddress(hMod,"CreateProcessA");
		Hook((LPVOID*)&pCreateProcessA, myCreateProcessA);
	}
}

extern "C" __declspec(dllexport) void  UnsetCreateProcessHookWrapper(const char* szParam)
{
	if (!g_b_hooked)
		return;

	UnHook((LPVOID*)&pCreateProcessInternalW,myCreateProcessInternalW);
	UnHook((LPVOID*)&pCreateProcessW,myCreateProcessW);
	UnHook((LPVOID*)&pCreateProcessA,myCreateProcessA);
}

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
		break;
	}
	return TRUE;
}

