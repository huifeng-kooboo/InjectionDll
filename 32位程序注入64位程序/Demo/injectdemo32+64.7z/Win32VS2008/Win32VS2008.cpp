// Win32VS2008.cpp : ����Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include "Win32VS2008.h"

INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	DialogBox(hInstance, MAKEINTRESOURCE(IDD_ABOUTBOX), NULL, About);
	return 0;
}

#include "../Detour/include/detours.h"
#pragma comment(lib,"../Detour/lib/x86/detours.lib")

bool g_b_hooked_msgboxa = false;

static int (WINAPI* OLD_MessageBoxW)(HWND hWnd,LPCWSTR lpText,LPCWSTR lpCaption,UINT uType) = MessageBoxW;
int WINAPI NEW_MessageBoxW(HWND hWnd,LPCWSTR lpText,LPCWSTR lpCaption,UINT uType)
{
	int ret = OLD_MessageBoxW(hWnd,L"����������޸�",L"[����]",uType);
	return ret;
}

void TestHook32()
{
	if (!g_b_hooked_msgboxa)
	{
		DetourRestoreAfterWith();
		DetourTransactionBegin();
		DetourUpdateThread(GetCurrentThread());

		//�������������ε���DetourAttach������HOOK�������
		DetourAttach(&(PVOID&)OLD_MessageBoxW,NEW_MessageBoxW);

		DetourTransactionCommit();	
	}
	else
	{
		DetourTransactionBegin();
		DetourUpdateThread(GetCurrentThread());

		//�������������ε���DetourDetach,���������������HOOK
		DetourDetach(&(PVOID&)OLD_MessageBoxW,NEW_MessageBoxW);

		DetourTransactionCommit();
	}
	MessageBoxW(NULL, NULL, NULL, NULL);
	g_b_hooked_msgboxa = !g_b_hooked_msgboxa;
}


typedef int (__fastcall *PAicLaunchAdminProcess)(WCHAR *lpApplicationName, 
												 WCHAR *lpCommandLine, 
												 void* a3, 
												 DWORD dwCreationFlags, 
												 WCHAR *lpCurrentDirectory, 
												 HWND a6, 
												 LPSTARTUPINFOW lpStartupInfo, 
												 LPPROCESS_INFORMATION lpProcessInformation, 
												 DWORD *a9);

PAicLaunchAdminProcess pAicLaunchAdminProcess = NULL;
int __fastcall myAicLaunchAdminProcess(WCHAR *lpApplicationName, 
									   WCHAR *lpCommandLine, 
									   void* a3, 
									   DWORD dwCreationFlags, 
									   WCHAR *lpCurrentDirectory, 
									   HWND a6, 
									   LPSTARTUPINFOW lpStartupInfo, 
									   LPPROCESS_INFORMATION lpProcessInformation, 
									   DWORD *a9)
{
	MessageBoxA(NULL, __FUNCTION__, __FUNCTION__, 0);
	return pAicLaunchAdminProcess(lpApplicationName,
		lpCommandLine, 
		a3, 
		dwCreationFlags, 
		lpCurrentDirectory, 
		a6, 
		lpStartupInfo, 
		lpProcessInformation, 
		a9);
}


typedef  int (__stdcall *PSHCreateProcess)(int p1,
										   HANDLE hToken,
										   wchar_t *lpApplicationName,
										   wchar_t * lpCommandLine,
										   DWORD dwCreationFlags,
										   LPSECURITY_ATTRIBUTES lpProcessAttributes,
										   LPSECURITY_ATTRIBUTES lpThreadAttributes,
										   BOOL bInheritHandles,
										   LPVOID lpEnvironment,
										   LPCWSTR lpCurrentDirectory,
										   LPSTARTUPINFOW lpStartupInfo,
										   LPPROCESS_INFORMATION lpProcessInformation,
										   int p2,
										   char p3,
										   int p4);

PSHCreateProcess pSHCreateProcess = NULL;

typedef BOOL (__stdcall *PGetMonitorInfo)(HMONITOR hMonitor,
										  LPMONITORINFO lpmi);
PGetMonitorInfo pGetMonitorInfo = NULL;

size_t AicLaunchAdminProcess_offset=0;

#include <stdio.h>
BOOL __stdcall myGetMonitorInfoW(HMONITOR hMonitor,
								LPMONITORINFO lpmi)
{
	void* aa=0;
#ifdef _WIN64
	HMODULE hMod=GetModuleHandleW(L"ntdll.dll");
	PRtlGetCallersAddress pFun=(PRtlGetCallersAddress)GetProcAddress(hMod,"RtlGetCallersAddress");
	void* b1,*b2;
	pFun(&b1,&b2);
	aa=b1;
#else
	__asm
	{
		mov eax, [ebp+4]
		mov aa,eax
	}
#endif
	long key,key2;
	char* i;
	bool ok=false;

	for (i=(char*)aa;i>=(char*)aa-0x200000;i--)
	{
		key=*(long*)i;	
		if (key==0xcccccccc)
		{
			ok=true;
			break;
		}
	}
	if(ok)
	{
		i+=4;
		HMODULE hMod=GetModuleHandleW(L"windows.storage.dll");
		pAicLaunchAdminProcess =(PAicLaunchAdminProcess)i;
// 		char buf[12] = {0};
// 		_snprintf_s(buf, 12, 11, "%08X", pAicLaunchAdminProcess);
// 		MessageBoxA(NULL, buf, NULL, NULL);
		AicLaunchAdminProcess_offset=(char*)pAicLaunchAdminProcess-(char*)hMod;
	}
	else
	{
		AicLaunchAdminProcess_offset=0;
		pAicLaunchAdminProcess =0;
	}
// 	ExitProcess(0);
	return 0;
}

long myIsUserAnAdmin()
{
	void* aa=0;
	__asm
	{
		mov eax, [ebp+4]
		mov aa,eax
	}

	long i,key,key2;
	bool ok=false;
	for (i=(long)aa;i>=(long)aa-0x200000;i--)
	{
		key=*(long*)i;
		key2=*(long*)(i+4);
		if (key==0x8b144d8b && key2==0x8d890845 )
			break;
	}
	for (;i>=(long)aa-0x200000;i--)
	{
		key=*(long*)i;

		if (key==0x90909090)
		{
			ok=true;
			break;
		}
	}
	if(ok)
	{
		i+=4;
		HMODULE hMod=GetModuleHandleW(L"shell32.dll");
		pSHCreateProcess =(PSHCreateProcess)i;
	}
	else
	{
		pSHCreateProcess =0;
	}
	return 1;
}

int mySHCreateProcess(int p1,
					   HANDLE hToken,
					   wchar_t *lpApplicationName,
					   wchar_t * lpCommandLine,
					   DWORD dwCreationFlags,
					   LPSECURITY_ATTRIBUTES lpProcessAttributes,
					   LPSECURITY_ATTRIBUTES lpThreadAttributes,
					   BOOL bInheritHandles,
					   LPVOID lpEnvironment,
					   LPCWSTR lpCurrentDirectory,
					   LPSTARTUPINFOW lpStartupInfo,
					   LPPROCESS_INFORMATION lpProcessInformation,
					   int p2,
					   char p3,
					   int p4)
{
	MessageBoxA(NULL, __FUNCTION__, __FUNCTION__, 0);

	return pSHCreateProcess(p1,
		hToken,
		lpApplicationName,
		lpCommandLine,
		dwCreationFlags,
		lpProcessAttributes,
		lpThreadAttributes,
		bInheritHandles,
		lpEnvironment,
		lpCurrentDirectory,
		lpStartupInfo,
		lpProcessInformation,
		p2,
		p3,
		p4);
}

#include "Shellapi.h"

typedef  BOOL  (__stdcall *PFShellExecuteExW)(SHELLEXECUTEINFO *pExecInfo);
PFShellExecuteExW oldShellExecuteExW = 0;

HANDLE RunAsAdmin( HWND hWnd, WCHAR* pFile,WCHAR* lpParam,WCHAR* pDir)
{
	PFShellExecuteExW pFun;
	if (oldShellExecuteExW==0)
	{
		pFun=ShellExecuteExW;
	}
	else
	{
		pFun=oldShellExecuteExW;
	}
	SHELLEXECUTEINFOW sei;

	ZeroMemory(&sei,sizeof(sei));
	sei.cbSize = sizeof(sei);
	sei.hwnd    = hWnd;
	sei.fMask  = 0x00000100|SEE_MASK_NOCLOSEPROCESS;
	sei.lpFile = pFile;
	sei.lpVerb = L"runas";
	sei.lpParameters=lpParam;
	sei.lpDirectory=pDir;
	//sei.lpParameters = PChar(aParameters);
	sei.nShow = SW_SHOWNORMAL;
	pFun(&sei);
	return sei.hProcess;
}

long Hook(void ** ppOld,PVOID pNew);
long UnHook(void ** ppFun,PVOID pDetour);

void* LocateFunc()
{
	HMODULE hModShell=GetModuleHandleW(L"shell32.dll");
	PVOID pIsUserAnAdmin=GetProcAddress(hModShell,"IsUserAnAdmin");
	PVOID pOldIsUserAnAdmin=pIsUserAnAdmin;
	Hook(&pOldIsUserAnAdmin,myIsUserAnAdmin);

	HMODULE hModUser32=GetModuleHandleW(L"user32.dll");
	PVOID pGetMonitorInfoW=GetProcAddress(hModUser32,"GetMonitorInfoW");
	PVOID pOldGetMonitorInfoW=pGetMonitorInfoW;
	Hook(&pOldGetMonitorInfoW,myGetMonitorInfoW);

	TerminateProcess(RunAsAdmin(0,L"explorer.exe",0,0),0);
	
	UnHook(&pOldIsUserAnAdmin,myIsUserAnAdmin);
	UnHook(&pOldGetMonitorInfoW,myGetMonitorInfoW);
	return pSHCreateProcess;
}

long UnHook(void ** ppFun,PVOID pDetour)
{
	//       DetourRestoreAfterWith();
	DetourTransactionBegin();
	//Detour
	DetourUpdateThread(GetCurrentThread());
	DetourDetach(ppFun,pDetour);
	return DetourTransactionCommit();
}


long Hook(void ** ppOld,PVOID pNew)
{
	//       DetourRestoreAfterWith();
	DetourTransactionBegin();
	//Detour
	DetourUpdateThread(GetCurrentThread());
	DetourAttach(ppOld,pNew);
	return DetourTransactionCommit();
}

void TestCreateProcess()
{
	PROCESS_INFORMATION info;
	STARTUPINFO si;
	memset(&si,0,sizeof(si));
	si.cb=sizeof(si);
	si.wShowWindow =SW_SHOW;
	si.dwFlags=STARTF_USESHOWWINDOW;
	WCHAR path[]=L"cmd";
	CreateProcess(NULL,path,NULL,NULL,0,CREATE_NEW_CONSOLE,NULL,NULL,&si,&info);
}

void HookCreateProcess()
{
	LocateFunc();
	
	Hook((LPVOID*)&pSHCreateProcess, mySHCreateProcess);
// 	if (pAicLaunchAdminProcess)
// 	{
// 		Hook((LPVOID*)&pAicLaunchAdminProcess, myAicLaunchAdminProcess);
// 	}

	TestCreateProcess();
}

// �����ڡ������Ϣ��������
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDOK:
		case IDCANCEL:
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		case IDB_NEWPROCESS:
			TestCreateProcess();
			break;
		default:
			{}
		}
	}
	return (INT_PTR)FALSE;
}


